--------------------------------------------------------------------------------

REPLACE VIEW PRD_EDW_GCFR_VM.GCFR_Stream_BusDate
AS
LOCKING ROW FOR ACCESS
SELECT
   Stream_Key
 , Cycle_Freq_Code
 , Business_Date
 , Next_Business_Date
 , Prev_Business_Date
 , Processing_Flag
 , Update_Date
 , Update_User
 , Update_Ts
FROM PRD_EDW_GCFR_TB.GCFR_Stream_BusDate
;