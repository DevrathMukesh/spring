using System.Globalization;

namespace LM.Settlement.Application;

public static class Helpers
{
    public static async Task<TResult> RunWithTimeout<TResult>(Task<TResult> task, TimeSpan timeout)
    {
        if (await Task.WhenAny(task, Task.Delay(timeout)) != task)
            throw new TimeoutException();

        return await task;
    }

    public static string ConvertToCurrency(decimal amount)
    {
        return $"Rp{amount.ToString("#,##0", CultureInfo.CreateSpecificCulture("id-ID"))}";
    }
}