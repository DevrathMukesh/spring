namespace LM.Settlement.Application.Options;

public class KafkaOptions
{
    public string BootstrapServers { get; set; } = string.Empty;
    public string ConsumerId { get; set; } = string.Empty;
    public Dictionary<string, string> TopicNames { get; set; } = new();
    public int MaxRetryAttempts { get; set; }
}

public static class TopicNameKeys
{
    public const string SettlementOnDemand = nameof(SettlementOnDemand);
    public const string SettlementOnDemandPayoutStatus = nameof(SettlementOnDemandPayoutStatus);
    public const string SettlementPayoutPending = nameof(SettlementPayoutPending);
}