using System.Text.Json.Serialization;

namespace LM.Settlement.Application.Dtos.Request;

public class BaseMtiPayload
{
    [JsonPropertyName("transactionDate")]
    public string TransactionDate { get; set; } = string.Empty;
    [JsonPropertyName("transactionTime")]
    public string TransactionTime { get; set; } = string.Empty;
    [JsonPropertyName("storeCode")]
    public string StoreCode { get; set; } = string.Empty;
}