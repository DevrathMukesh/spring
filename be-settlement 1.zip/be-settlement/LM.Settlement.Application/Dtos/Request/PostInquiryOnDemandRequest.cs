using System.Text.Json.Serialization;

namespace LM.Settlement.Application.Dtos.Request;

public class PostInquiryOnDemandRequest : BaseMtiPayload
{
    [JsonPropertyName("referenceNo")]
    public string ReferenceNo { get; set; } = string.Empty;
}