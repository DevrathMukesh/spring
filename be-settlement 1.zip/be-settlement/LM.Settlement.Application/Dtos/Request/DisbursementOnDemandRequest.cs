using System.Text.Json.Serialization;

namespace LM.Settlement.Application.Dtos.Request;

public class DisbursementOnDemandRequest : BaseMtiPayload
{
    [JsonPropertyName("userAppID")] 
    public string UserAppId { get; set; } = string.Empty;
    [JsonPropertyName("amount")] 
    public string Amount { get; set; } = string.Empty;
    [JsonPropertyName("referenceNo")]
    public string ReferenceNo { get; set; } = string.Empty;
}