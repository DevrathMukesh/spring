using System.Text.Json.Serialization;

namespace LM.Settlement.Application.Dtos.Request;

public class PostInquiryDisbursementRequest : BaseMtiPayload
{
    [JsonPropertyName("userAppID")]
    public string UserAppId { get; set; } = string.Empty;
}