using System.Text.Json.Serialization;

namespace LM.Settlement.Application.Dtos.Request;

public class PostChangeSettlementTypeRequest : BaseMtiPayload
{
    [JsonPropertyName("userAppID")]
    public string UserAppId { get; set; } = string.Empty;
    [JsonPropertyName("settlementType")]
    public string SettlementType { get; set; } = string.Empty;
}