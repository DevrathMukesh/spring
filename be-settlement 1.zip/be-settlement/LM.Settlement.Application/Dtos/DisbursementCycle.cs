using System.Text.Json.Serialization;

namespace LM.Settlement.Application.Dtos;

public class DisbursementCycle
{
    [JsonPropertyName("settlementType")]
    public string SettlementType { get; set; } = string.Empty;
    [JsonPropertyName("day")]
    public List<string> Day { get; set; } = [];
    [JsonPropertyName("date")]
    public List<string> Date { get; set; } = [];
    [JsonPropertyName("hour")]
    public List<string> Hour { get; set; } = [];
}