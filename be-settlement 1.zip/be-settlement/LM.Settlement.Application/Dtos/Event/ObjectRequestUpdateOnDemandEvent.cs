namespace LM.Settlement.Application.Dtos.Event;

public class ObjectRequestUpdateOnDemandEvent
{
    public Guid TransactionId { get; set; }
    public Guid OutletId { get; set; }
}