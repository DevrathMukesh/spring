namespace LM.Settlement.Application.Dtos.Event;

public class ObjectPayoutPendingEvent
{
    public string FileName { get; set; } = string.Empty;
    public Guid OutletId { get; set; }
    public Guid StoreId { get; set; }
}