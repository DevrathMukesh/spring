using System.Text.Json.Serialization;

namespace LM.Settlement.Application.Dtos.Response;

public class OpenApiGetToken
{
    [JsonPropertyName("result")]
    public TokenData Result { get; set; } = new();
    [JsonPropertyName("error")]
    public object? Error { get; set; }
    [JsonPropertyName("status")]
    public bool? Status { get; set; }
    [JsonPropertyName("httpStatusCode")]
    public int? HttpStatusCode { get; set; }
}
public class TokenData
{
    [JsonPropertyName("responseCode")]
    public string ResponseCode { get; set; } = "";
    [JsonPropertyName("responseMessage")]
    public string ResponseMessage { get; set; } = "";
    [JsonPropertyName("accessToken")]
    public string AccessToken { get; set; } = "";
    [JsonPropertyName("tokenType")]
    public string TokenType { get; set; } = "";
    [JsonPropertyName("expireIn")]
    public string ExpireIn { get; set; } = "";
}