using System.Text.Json.Serialization;

namespace LM.Settlement.Application.Dtos.Response;

public class OpenApiGetSignature
{
    [JsonPropertyName("result")]
    public SignatureData Result { get; set; } = new();
    [JsonPropertyName("error")]
    public object? Error { get; set; }
    [JsonPropertyName("status")]
    public bool? Status { get; set; }
    [JsonPropertyName("httpStatusCode")]
    public int? HttpStatusCode { get; set; }
}

public class SignatureData
{
    [JsonPropertyName("signature")]
    public string Signature { get; set; } = "";
}