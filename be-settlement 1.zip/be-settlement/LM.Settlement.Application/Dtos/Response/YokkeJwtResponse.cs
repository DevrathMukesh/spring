using System.Text.Json.Serialization;

namespace LM.Settlement.Application.Dtos.Response;

public class YokkeJwtResponse
{
    [JsonPropertyName("jwt")]
    public string Jwt { get; set; } = string.Empty;

}