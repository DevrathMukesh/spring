using System.Text.Json.Serialization;

namespace LM.Settlement.Application.Dtos.Response;

public class OpenApiGetHmac
{
    [JsonPropertyName("result")]
    public HmacData Result { get; set; } = new();
    [JsonPropertyName("error")]
    public object? Error { get; set; } = new();
    [JsonPropertyName("status")]
    public bool? Status { get; set; } = false;
    [JsonPropertyName("httpStatusCode")]
    public int? HttpStatusCode { get; set; }
}

public class HmacData
{
    [JsonPropertyName("hmac")]
    public string Hmac { get; set; } = "";
}