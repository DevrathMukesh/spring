﻿using System.Text.Json;
using LM.Settlement.Application.Contracts.Infrastructure.Internal;
using LM.Settlement.Application.Dtos.Response;
using MediatR;
using Microsoft.AspNetCore.Http;

namespace LM.Settlement.Application.Features.Commands.Oauth2.GetSignature
{
    public class GetSignatureHandler : IRequestHandler<GetSignatureCommand, GetSignResponse>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IOpenApi _openApi;

        public GetSignatureHandler(IHttpContextAccessor httpContextAccessor, IOpenApi openApi)
        {
            _httpContextAccessor = httpContextAccessor;
            _openApi = openApi;
        }

        public async Task<GetSignResponse> Handle(GetSignatureCommand param, CancellationToken cancellationToken)
        {
            string password = _httpContextAccessor.HttpContext.Request.Headers["KeyPassword"].ToString();
            string message = _httpContextAccessor.HttpContext.Request.Headers["Message"].ToString();
            string auth = _httpContextAccessor.HttpContext.Request.Headers["Authorization"].ToString();

            var signRes = await _openApi.GetSignature(password, message, auth);
            var signObject = JsonSerializer.Deserialize<OpenApiGetSignature>(signRes);
            GetSignResponse response = new GetSignResponse
            {
                Signature = signObject?.Result.Signature ?? ""
            };

            return response;
        }
    }
}