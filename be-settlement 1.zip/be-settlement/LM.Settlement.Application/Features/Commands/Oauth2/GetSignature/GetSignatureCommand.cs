﻿using MediatR;

namespace LM.Settlement.Application.Features.Commands.Oauth2.GetSignature
{
    public class GetSignatureCommand : IRequest<GetSignResponse>
    {
    }

    public class GetSignResponse
    {
        public string Signature { get; set; } = string.Empty;
    }
}