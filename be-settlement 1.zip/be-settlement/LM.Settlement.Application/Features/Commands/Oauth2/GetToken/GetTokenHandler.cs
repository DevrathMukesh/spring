﻿using System.Text.Json;
using LM.Settlement.Application.Contracts.Infrastructure.Internal;
using LM.Settlement.Application.Dtos.Response;
using MediatR;
using Microsoft.AspNetCore.Http;

namespace LM.Settlement.Application.Features.Commands.Oauth2.GetToken
{
    public class GetTokenHandler : IRequestHandler<GetTokenCommand, GetTokenResponse>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IOpenApi _openApi;

        public GetTokenHandler(IHttpContextAccessor httpContextAccessor, IOpenApi openApi)
        {
            _httpContextAccessor = httpContextAccessor;
            _openApi = openApi;
        }

        public async Task<GetTokenResponse> Handle(GetTokenCommand param, CancellationToken cancellationToken)
        {
            string signature = _httpContextAccessor.HttpContext.Request.Headers["X-SIGNATURE"].ToString();
            string timestamp = _httpContextAccessor.HttpContext.Request.Headers["X-TIMESTAMP"].ToString();
            string xClientKey = _httpContextAccessor.HttpContext.Request.Headers["X-CLIENT-KEY"].ToString();
            var tokenRes = await _openApi.GetToken(signature, timestamp, xClientKey);
            var tokenObj = JsonSerializer.Deserialize<OpenApiGetToken>(tokenRes);

            return new GetTokenResponse
            {
                ResponseCode = tokenObj?.Result.ResponseCode ?? "",
                ResponseMessage = tokenObj?.Result.ResponseMessage ?? "",
                AccessToken = tokenObj?.Result.AccessToken ?? "",
                TokenType = tokenObj?.Result.TokenType ?? "",
                ExpireIn = tokenObj?.Result.ExpireIn ?? ""
            };
        }
    }
}