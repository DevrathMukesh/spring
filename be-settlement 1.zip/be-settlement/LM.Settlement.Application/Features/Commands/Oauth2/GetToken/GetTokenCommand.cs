﻿using MediatR;

namespace LM.Settlement.Application.Features.Commands.Oauth2.GetToken
{
    public class GetTokenCommand : IRequest<GetTokenResponse>
    {
        public string GrantType { get; set; } = string.Empty;
    }

    public class GetTokenResponse
    {
        public string ResponseCode { get; set; } = string.Empty;
        public string ResponseMessage { get; set; } = string.Empty;
        public string AccessToken { get; set; } = string.Empty;
        public string TokenType { get; set; } = string.Empty;
        public string ExpireIn { get; set; } = string.Empty;
    }
}