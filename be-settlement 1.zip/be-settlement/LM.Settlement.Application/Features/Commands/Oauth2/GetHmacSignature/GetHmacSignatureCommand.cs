﻿using MediatR;

namespace LM.Settlement.Application.Features.Commands.Oauth2.GetHmacSignature
{
    public class GetHmacSignatureCommand : IRequest<GetHmacSignatureResponse>
    {
    }

    public class GetHmacSignatureResponse
    {
        public string Sign2 { get; set; } = "";
        public string HmacHex { get; set; } = "";
    }
}