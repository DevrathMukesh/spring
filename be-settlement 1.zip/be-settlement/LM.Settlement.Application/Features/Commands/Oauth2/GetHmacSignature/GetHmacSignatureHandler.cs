﻿using System.Text.Json;
using LM.Settlement.Application.Contracts.Infrastructure.Internal;
using LM.Settlement.Application.Dtos.Response;
using MediatR;
using Microsoft.AspNetCore.Http;

namespace LM.Settlement.Application.Features.Commands.Oauth2.GetHmacSignature;

public class GetHmacSignatureHandler : IRequestHandler<GetHmacSignatureCommand, GetHmacSignatureResponse>
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly IOpenApi _openApi;

    public GetHmacSignatureHandler(IHttpContextAccessor httpContextAccessor, IOpenApi openApi)
    {
        _httpContextAccessor = httpContextAccessor;
        _openApi = openApi;
    }

    public async Task<GetHmacSignatureResponse> Handle(GetHmacSignatureCommand request,
        CancellationToken cancellationToken)
    {
        GetHmacSignatureResponse response = new GetHmacSignatureResponse();
        string postMessage = _httpContextAccessor.HttpContext.Request.Headers["PostMessage"].ToString();
        string clientSecret = _httpContextAccessor.HttpContext.Request.Headers["ClientSecret"].ToString();

        var hmacSignatureRes = await _openApi.GetHmacSignature(postMessage, clientSecret);
        var hmacSignatureObj = JsonSerializer.Deserialize<OpenApiGetHmacSignature>(hmacSignatureRes);

        response.Sign2 = hmacSignatureObj?.Result.Sign2 ?? "";
        response.HmacHex = hmacSignatureObj?.Result.HmacHex ?? "";
        return response;
    }
}