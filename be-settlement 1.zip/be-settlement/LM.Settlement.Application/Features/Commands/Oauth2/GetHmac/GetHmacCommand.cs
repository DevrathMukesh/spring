﻿using MediatR;

namespace LM.Settlement.Application.Features.Commands.Oauth2.GetHmac
{
    public class GetHmacCommand : IRequest<GetHmacResponse>
    {
    }

    public class GetHmacResponse
    {
        public string Hmac { get; set; } = "";
    }
}