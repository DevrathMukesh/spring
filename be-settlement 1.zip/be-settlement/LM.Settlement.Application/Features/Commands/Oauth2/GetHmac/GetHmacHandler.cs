﻿using System.Text.Json;
using LM.Settlement.Application.Contracts.Infrastructure.Internal;
using LM.Settlement.Application.Dtos.Response;
using MediatR;
using Microsoft.AspNetCore.Http;

namespace LM.Settlement.Application.Features.Commands.Oauth2.GetHmac
{
    public class GetHmacHandler : IRequestHandler<GetHmacCommand, GetHmacResponse>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IOpenApi _openApi;

        public GetHmacHandler(IHttpContextAccessor httpContextAccessor, IOpenApi openApi)
        {
            _httpContextAccessor = httpContextAccessor;
            _openApi = openApi;
        }

        public async Task<GetHmacResponse> Handle(GetHmacCommand request, CancellationToken cancellationToken)
        {
            string httpMethod = _httpContextAccessor.HttpContext.Request.Headers["HttpMethod"].ToString();
            string endpointUrl = _httpContextAccessor.HttpContext.Request.Headers["Path"].ToString();
            string accessToken = _httpContextAccessor.HttpContext.Request.Headers["BearerToken"].ToString();
            string reqBody = _httpContextAccessor.HttpContext.Request.Headers["ReqPayload"].ToString();
            string timeStamp = _httpContextAccessor.HttpContext.Request.Headers["TimeStamp"].ToString();

            var hmacRes = await _openApi.GetHmac(httpMethod, endpointUrl, accessToken, reqBody, timeStamp);
            var hmacObj = JsonSerializer.Deserialize<OpenApiGetHmac>(hmacRes);
            var response = new GetHmacResponse
            {
                Hmac = hmacObj?.Result.Hmac ?? ""
            };
            return response;
        }
    }
}