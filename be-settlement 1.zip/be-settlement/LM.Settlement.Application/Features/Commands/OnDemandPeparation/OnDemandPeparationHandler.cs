using LivinMerchant.General.Base.Exceptions;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.Data.Settlement;
using MediatR;
using Microsoft.AspNetCore.Http;

namespace LM.Settlement.Application.Features.Commands.OnDemandPeparation;

public class OnDemandPeparationHandler : IRequestHandler<OnDemandPeparationCommand, OnDemandPeparationResponse>
{
    private readonly IConfigRepository _configRepository;
    private readonly IDisbursementStageRepository _disbursementStageRepository;
    private readonly IDisbursementInquiryRepository _disbursementInquiryRepository;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public OnDemandPeparationHandler(IConfigRepository configRepository,
        IDisbursementStageRepository disbursementStageRepository, IHttpContextAccessor httpContextAccessor,
        IDisbursementInquiryRepository disbursementInquiryRepository)
    {
        _configRepository = configRepository;
        _disbursementStageRepository = disbursementStageRepository;
        _httpContextAccessor = httpContextAccessor;
        _disbursementInquiryRepository = disbursementInquiryRepository;
    }

    public async Task<OnDemandPeparationResponse> Handle(OnDemandPeparationCommand request,
        CancellationToken cancellationToken)
    {
        var userId = Guid.Parse(_httpContextAccessor.HttpContext.Items["UserId"] as string ?? string.Empty);
        var storeId = Guid.Parse(_httpContextAccessor.HttpContext.Items["StoreId"] as string ?? string.Empty);
        var outletId = Guid.Parse(_httpContextAccessor.HttpContext.Items["OutletId"] as string ?? string.Empty);
        var isAccountOwner =
            bool.Parse(_httpContextAccessor.HttpContext.Items["IsAccountOwner"] as string ?? "false");
        if (!isAccountOwner) throw new UnauthorizedException("Access Denied");

        var configs = (
            from c in await _configRepository.GetFromRedis()
            where c.ParameterKey == "settlement.token.expiredTime"
                  || c.ParameterKey == "settlement.ondemand.minAmount"
            select c).ToList();
        var tokenExpiredString = configs
            .FirstOrDefault(c => c.ParameterKey == "settlement.token.expiredTime")?.ParameterValue;
        var minWithdrawalAmountString = configs
            .FirstOrDefault(c => c.ParameterKey == "settlement.ondemand.minAmount")?.ParameterValue;
        var tokenExpired = int.Parse(tokenExpiredString ?? "0");        
        var minWithdrawalAmount = decimal.Parse(minWithdrawalAmountString ?? "10000");
        if (request.WithdrawalAmount < minWithdrawalAmount)
        {
            throw new BadRequestException("Invalid request");
        }
        
        var disbursementInquiryLog = (
            from ds in _disbursementInquiryRepository.GetQueryable<DisbursementInquiry>()
            where ds.StoreId == storeId && ds.OutletId == outletId && ds.UserId == userId &&
                  ds.InquiryId == request.InquiryId
            select ds
        ).FirstOrDefault();

        if (disbursementInquiryLog == null) throw new NotFoundException("Data not found");
        
        if (disbursementInquiryLog.AvailableBalance < request.WithdrawalAmount)
            throw new BadRequestException("Invalid request");

        var onDemandType = disbursementInquiryLog.AvailableBalance > request.WithdrawalAmount ? "partial" : "full";
        var newTransactionId = Guid.NewGuid();

        var newDisbursementStage = new DisbursementStage
        {
            TransactionId = newTransactionId,
            UserId = userId,
            StoreId = storeId,
            OutletId = outletId,
            Gid = disbursementInquiryLog.Gid,
            DisbursementRef = disbursementInquiryLog.DisbursementRef,
            InquiryDatetime = disbursementInquiryLog.InquiryDatetime,
            AvailableBalance = disbursementInquiryLog.AvailableBalance,
            WithdrawalAmount = request.WithdrawalAmount,
            SettlementType = disbursementInquiryLog.SettlementType,
            ExpiryTime = DateTime.Now.AddMinutes(tokenExpired),
            OndemandType = onDemandType,
            StoreCode = disbursementInquiryLog.StoreCode,
            IsUsed = false
        };

        await _disbursementStageRepository.CreateAsync(newDisbursementStage);
        
        return new OnDemandPeparationResponse
        {
            ResponseCode = "00",
            TransactionId = newTransactionId,
            InquiryId = request.InquiryId,
            WithdrawalAmount = request.WithdrawalAmount
        };
    }
}