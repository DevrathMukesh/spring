using MediatR;

namespace LM.Settlement.Application.Features.Commands.OnDemandPeparation;

public class OnDemandPeparationCommand : IRequest<OnDemandPeparationResponse>
{
    public Guid InquiryId { get; set; }
    public decimal WithdrawalAmount { get; set; }
}