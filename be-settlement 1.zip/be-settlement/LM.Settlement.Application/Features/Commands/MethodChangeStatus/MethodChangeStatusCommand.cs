using System.ComponentModel.DataAnnotations;
using MediatR;

namespace LM.Settlement.Application.Features.Commands.MethodChangeStatus;

public class MethodChangeStatusCommand : IRequest<MethodChangeStatusResponse>
{
    [Required]
    public string StatusCode { get; set; } = string.Empty;
    [Required]
    public string StoreCode { get; set; } = string.Empty;
    public string StatusMessage { get; set; } = string.Empty;
    public string UserAppId { get; set; } = string.Empty;
}