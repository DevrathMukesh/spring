using System.Text.Json.Serialization;

namespace LM.Settlement.Application.Features.Commands.MethodChangeStatus;

public class MethodChangeStatusResponse
{
    public string ResponseCode { get; set; } = string.Empty;
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? StoreCode { get; set; }
}