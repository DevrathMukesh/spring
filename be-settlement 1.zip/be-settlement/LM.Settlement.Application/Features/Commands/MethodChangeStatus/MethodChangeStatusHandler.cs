using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.Data;
using LM.Settlement.Domain.Models.Data.Settlement;
using MediatR;

namespace LM.Settlement.Application.Features.Commands.MethodChangeStatus;

public class MethodChangeStatusHandler : IRequestHandler<MethodChangeStatusCommand, MethodChangeStatusResponse>
{
    private readonly ISettlementChangeRepository _settlementChangeRepository;
    private readonly IOutletsRepository _outletsRepository;

    public MethodChangeStatusHandler(ISettlementChangeRepository settlementChangeRepository,
        IOutletsRepository outletsRepository)
    {
        _settlementChangeRepository = settlementChangeRepository;
        _outletsRepository = outletsRepository;
    }

    public async Task<MethodChangeStatusResponse> Handle(MethodChangeStatusCommand request,
        CancellationToken cancellationToken)
    {
        var getHistorySettlementChange = (from sc in _settlementChangeRepository.GetQueryable<SettlementChange>()
                where sc.StoreCode == request.StoreCode && sc.UserAppId == request.UserAppId && !sc.IsDeleted
                orderby sc.ChangesDate descending
                select sc
            ).FirstOrDefault();

        if (getHistorySettlementChange == null)
        {
            return new MethodChangeStatusResponse { ResponseCode = "01" };
        }

        if (request.StatusCode == "00")
        {
            var updateOutlet = (from ot in _outletsRepository.GetQueryable<Outlets>()
                where ot.OutletId == getHistorySettlementChange.OutletId && !ot.IsDeleted
                select ot).FirstOrDefault();

            if (updateOutlet == null)
            {
                return new MethodChangeStatusResponse { ResponseCode = "01" };
            }

            updateOutlet.SettlementType = getHistorySettlementChange.NewType;
            await _outletsRepository.UpdateAsync(updateOutlet);
        }
        else
        {
            getHistorySettlementChange.IsDeleted = true;
        }

        getHistorySettlementChange.StatusCode = request.StatusCode;
        await _settlementChangeRepository.UpdateAsync(getHistorySettlementChange);

        return new MethodChangeStatusResponse
        {
            ResponseCode = "00",
            StoreCode = getHistorySettlementChange.StoreCode
        };
    }
}