using System.Text.Json.Serialization;

namespace LM.Settlement.Application.Features.Commands.OnDemandBalanceInquiry;

public class OnDemandBalanceInquiryResponse
{
    public string ResponseCode { get; set; } = string.Empty;
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public Guid OutletId { get; set; }
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public Guid InquiryId { get; set; }
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public DateTime InquiryDateTime { get; set; }
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public string StoreCode { get; set; } = string.Empty;
    public decimal TotalAvailableBalance { get; set; } 
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public string TotalIncome { get; set; } = string.Empty;
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public string HoldAmt { get; set; } = string.Empty;
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public string NextCycle { get; set; } = string.Empty;
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public DetailBalanceInquiry Detail { get; set; } = new();
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public MinAmountParameter Parameter { get; set; } = new();
}

public class DetailBalanceInquiry
{
    public string Mdr { get; set; } = string.Empty;
    public string MdrAmount { get; set; } = string.Empty;
    public string SharingFee { get; set; } = string.Empty;
    public string SharingAmountFee { get; set; } = string.Empty;
    public string TotalDisbursed { get; set; } = string.Empty;
}

public class MinAmountParameter
{
    public decimal MinAmount { get; set; }
}