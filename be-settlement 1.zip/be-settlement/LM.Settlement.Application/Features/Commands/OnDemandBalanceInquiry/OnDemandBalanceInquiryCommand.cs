using MediatR;

namespace LM.Settlement.Application.Features.Commands.OnDemandBalanceInquiry;

public class OnDemandBalanceInquiryCommand :IRequest<OnDemandBalanceInquiryResponse>
{
    
}