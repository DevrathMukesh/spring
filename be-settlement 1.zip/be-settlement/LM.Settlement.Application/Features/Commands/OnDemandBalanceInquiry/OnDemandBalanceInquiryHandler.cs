using System.Globalization;
using System.Text.Json;
using LivinMerchant.General.Base.Class.Logger;
using LivinMerchant.General.Base.Exceptions;
using LivinMerchant.Kafka.Models;
using LivinMerchant.Kafka.Services;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Application.Contracts.Infrastructure.ISeller;
using LM.Settlement.Application.Contracts.Infrastructure.Mti;
using LM.Settlement.Application.Dtos;
using LM.Settlement.Application.Dtos.Event;
using LM.Settlement.Application.Dtos.Request;
using LM.Settlement.Application.Options;
using LM.Settlement.Domain.Models.Data.Settlement;
using LM.Settlement.Domain.Models.Surrounding.ISeller;
using LM.Settlement.Domain.Models.Surrounding.Yokke;
using LM.Settlement.Domain.Models.System;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using KafkaOptions = LM.Settlement.Application.Options.KafkaOptions;

namespace LM.Settlement.Application.Features.Commands.OnDemandBalanceInquiry;

public class
    OnDemandBalanceInquiryHandler : IRequestHandler<OnDemandBalanceInquiryCommand, OnDemandBalanceInquiryResponse>
{
    private readonly IConfigRepository _configRepository;
    private readonly IDisbursementInquiryRepository _disbursementInquiryRepository;
    private readonly IDisbursementTrxRepository _disbursementTrxRepository;
    private readonly IMtiRequestsRepository _imtiRequestsRepository;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly IiSellerApi _iSellerApi;
    private readonly IYokkeApi _yokkeApi;
    private readonly IProducerService _producerService;
    private readonly KafkaOptions _kafkaOptions;
    private static readonly IProducerService ProducerService = new ProducerService();
    private static readonly ILoggerFactory LoggerFactory = new LoggerFactory();
    private static readonly IAppLogger<LoggingEvent> Logger =
        new LoggerAdapter<LoggingEvent>(LoggerFactory, ProducerService);

    public OnDemandBalanceInquiryHandler(IConfigRepository configRepository,
        IDisbursementInquiryRepository disbursementInquiryRepository,
        IDisbursementTrxRepository disbursementTrxRepository, IMtiRequestsRepository imtiRequestsRepository,
        IiSellerApi iSellerApi, IHttpContextAccessor httpContextAccessor, IYokkeApi yokkeApi,
        IProducerService producerService, IOptions<KafkaOptions> options)
    {
        _configRepository = configRepository;
        _disbursementInquiryRepository = disbursementInquiryRepository;
        _disbursementTrxRepository = disbursementTrxRepository;
        _imtiRequestsRepository = imtiRequestsRepository;
        _iSellerApi = iSellerApi;
        _httpContextAccessor = httpContextAccessor;
        _yokkeApi = yokkeApi;
        _producerService = producerService;
        _kafkaOptions = options.Value;
    }

    public async Task<OnDemandBalanceInquiryResponse> Handle(OnDemandBalanceInquiryCommand request,
        CancellationToken cancellationToken)
    {
        var isAccountOwner = bool.Parse(_httpContextAccessor.HttpContext.Items["IsAccountOwner"] as string ?? "false");
        var storeId = Guid.Parse(_httpContextAccessor.HttpContext.Items["StoreId"] as string ?? string.Empty);
        var outletId = Guid.Parse(_httpContextAccessor.HttpContext.Items["OutletId"] as string ?? string.Empty);
        var userId = Guid.Parse(_httpContextAccessor.HttpContext.Items["UserId"] as string ?? string.Empty);

        if (!isAccountOwner) throw new UnauthorizedException("Access Denied");
        var configs =
            (from c in await _configRepository.GetFromRedis()
                where c.ParameterKey == "settlement.MTI.timeoutMax"
                      || c.ParameterKey == "settlement.MTI.requestMaxRetry"
                      || c.ParameterKey == "settlement.token.expiredTime"
                      || c.ParameterKey.Contains("settlement.ondemand")
                select c).ToList();

        var maxRetryString = configs.FirstOrDefault(x => x.ParameterKey == "settlement.MTI.requestMaxRetry")
            ?.ParameterValue;
        var maxRetry = string.IsNullOrEmpty(maxRetryString) ? 3 : int.Parse(maxRetryString);
        var minAmountString = configs.FirstOrDefault(x => x.ParameterKey == "settlement.ondemand.minAmount")
            ?.ParameterValue;

        decimal minAmount = 0;
        if (!string.IsNullOrWhiteSpace(minAmountString) && decimal.TryParse(minAmountString, out var parsedValue))
        {
            minAmount = parsedValue;
        }

        GetOutletSettlementTypeResponse outletSettlementType = await _iSellerApi.GetOutletSettlementType();
        var newMtiRequest = new MtiRequests
        {
            StoreId = storeId,
            Status = "done",
            CreatedDate = DateTime.Now,
            Type = "on_demand",
            OutletId = outletId
        };
        await _imtiRequestsRepository.CreateAsync(newMtiRequest);

        var userAppId = newMtiRequest.MtiRequestId;

        var inquiryDisburseRequest = new PostInquiryDisbursementRequest
        {
            TransactionDate = DateTime.Now.ToString("yyyyMMdd"),
            TransactionTime = DateTime.Now.ToString("HHmmss"),
            UserAppId = ((long)userAppId).ToBase36String(),
            StoreCode = outletSettlementType.StoreCode
        };

        var retryAttempt = 0;
        var inquiryDisbursementResponse = new PostInquiryDisbursementResponse();

        while (retryAttempt < maxRetry)
        {
            try
            {
                inquiryDisbursementResponse = await _yokkeApi.InquiryDisbursement(inquiryDisburseRequest);
                break;
            }
            catch (Exception e)
            {
                Logger.WriteLog(level: "ERROR", startTime: DateTimeOffset.Now.ToUnixTimeMilliseconds(),
                    action: "InquiryDisbursement", method: "POST",
                    url: "/yokke/api/inquiryDisbursement", message: $"Error: {e.Message}",
                    source: "OnDemandBalanceInquiryHandler");
                retryAttempt++;
                if (retryAttempt == maxRetry)
                {
                    return new OnDemandBalanceInquiryResponse
                    {
                        ResponseCode = "01",
                    };
                }
            }
        }

        var payoutOnDemandResponse = await _iSellerApi.GetPayoutOndemand();

        var getTimeoutDataDisburse = (from trx in _disbursementTrxRepository.GetQueryable<DisbursementTrx>()
                where trx.StoreId == storeId && trx.OutletId == outletId && trx.Response == "68" && !trx.IsDeleted
                select trx
            ).FirstOrDefault();

        if (getTimeoutDataDisburse != null)
        {
            try
            {
                var inquiryOnDemandRequest = new PostInquiryOnDemandRequest
                {
                    TransactionDate = DateTime.Now.ToString("yyyymmdd"),
                    TransactionTime = DateTime.Now.ToString("HHmmss"),
                    StoreCode = outletSettlementType.StoreCode,
                    ReferenceNo = getTimeoutDataDisburse.ReffNo
                };
                var onDemandResponse = await _yokkeApi.InquiryOnDemand(inquiryOnDemandRequest);
                if (onDemandResponse.ResponseCode == "00")
                {
                    getTimeoutDataDisburse.Response = "00";
                    getTimeoutDataDisburse.ModifiedDate = DateTime.Now;
                    await _disbursementTrxRepository.UpdateAsync(getTimeoutDataDisburse);
                    var objectRequest = new ObjectRequestUpdateOnDemandEvent
                    {
                        TransactionId = getTimeoutDataDisburse.TransactionId,
                        OutletId = getTimeoutDataDisburse.OutletId
                    };
                    var ondemandTopic = _kafkaOptions.TopicNames[TopicNameKeys.SettlementOnDemand];
                    await _producerService.ProduceAsync(ondemandTopic,
                        new GeneralEvent<ObjectRequestUpdateOnDemandEvent>
                            { Content = objectRequest, EventCode = "settlement_ondemand_update" });
                }
            }
            catch (Exception e)
            {
                Logger.WriteLog(level: "ERROR", startTime: DateTimeOffset.Now.ToUnixTimeMilliseconds(),
                    action: "InquiryOnDemand", method: "POST",
                    url: "/yokke/api/inquiryOnDemand", message: $"Error: {e.Message}",
                    source: "OnDemandBalanceInquiryHandler");
                return new OnDemandBalanceInquiryResponse
                {
                    ResponseCode = "01",
                };
            }
        }

        var userSettlementType = outletSettlementType.SettlementType;
        var configSettlementTypeString = configs.FirstOrDefault(x => x.ParameterKey == "settlement.ondemand.nextCycle")
            ?.ParameterValue;
        var configsSettlementType =
            JsonSerializer.Deserialize<List<DisbursementCycle>>(configSettlementTypeString ?? string.Empty);
        if (configsSettlementType == null) throw new NotFoundException("Invalid Config");
        var userConfig = configsSettlementType.FirstOrDefault(x => x.SettlementType == userSettlementType);
        var nextCycle = GenerateNextCycle(userSettlementType, userConfig);

        var inquiryDateTimeString = inquiryDisbursementResponse.AuthorizationDate +
                                    inquiryDisbursementResponse.AuthorizationTime;
        var inquiryDateTime =
            DateTime.ParseExact(inquiryDateTimeString, "yyyyMMddHHmmss", CultureInfo.InvariantCulture);
        var newInquiryId = Guid.NewGuid();

        var newDisburseInquiry = new DisbursementInquiry
        {
            InquiryId = newInquiryId,
            UserId = userId,
            StoreId = storeId,
            OutletId = outletId,
            Gid = outletSettlementType.Gid,
            DisbursementRef = DateTime.Now.ToString("yyyymmddHHmmss"),
            InquiryDatetime = inquiryDateTime,
            AvailableBalance = Convert.ToDecimal(inquiryDisbursementResponse.Amount),
            SettlementType = inquiryDisbursementResponse.SettlementType,
            StoreCode = outletSettlementType.StoreCode
        };

        await _disbursementInquiryRepository.CreateAsync(newDisburseInquiry);


        var totalIncome = decimal.Parse(inquiryDisbursementResponse.Amount, CultureInfo.InvariantCulture) +
                          decimal.Parse(inquiryDisbursementResponse.AmountMdr, CultureInfo.InvariantCulture) +
                          decimal.Parse(inquiryDisbursementResponse.AmountFee, CultureInfo.InvariantCulture);
        var mdrAmount =
            Helpers.ConvertToCurrency(
                decimal.Parse(inquiryDisbursementResponse.AmountMdr, CultureInfo.InvariantCulture));
        mdrAmount = $"-{mdrAmount}";
        var amountFee =
            Helpers.ConvertToCurrency(
                decimal.Parse(inquiryDisbursementResponse.AmountFee, CultureInfo.InvariantCulture));
        amountFee = $"-{amountFee}";
        var totalDisbursed = payoutOnDemandResponse.Payouts.Sum(p => p.Amount);
        return new OnDemandBalanceInquiryResponse
        {
            ResponseCode = "00",
            OutletId = outletId,
            InquiryId = newInquiryId,
            InquiryDateTime = inquiryDateTime,
            StoreCode = outletSettlementType.StoreCode,
            TotalAvailableBalance = decimal.Parse(inquiryDisbursementResponse.Amount, CultureInfo.InvariantCulture),
            TotalIncome = Helpers.ConvertToCurrency(totalIncome),
            HoldAmt = Helpers.ConvertToCurrency(decimal.Parse(inquiryDisbursementResponse.HoldAmt,
                CultureInfo.InvariantCulture)),
            NextCycle = nextCycle ?? "",
            Detail = new DetailBalanceInquiry
            {
                Mdr = inquiryDisbursementResponse.Mdr,
                MdrAmount = mdrAmount,
                SharingFee = inquiryDisbursementResponse.SharingFee,
                SharingAmountFee = amountFee,
                TotalDisbursed = Helpers.ConvertToCurrency(totalDisbursed)
            },
            Parameter = new MinAmountParameter
            {
                MinAmount = minAmount
            }
        };
    }

    private static string? GenerateNextCycle(string? userSettlementType, DisbursementCycle? userConfig)
    {
        var nextCycle = "";
        DateTime now = DateTime.Now;
        switch (userSettlementType)
        {
            case "05" or "06":
                nextCycle = userConfig?.Hour.Where(x =>
                        DateTime.ParseExact(x, "HH:mm", CultureInfo.InvariantCulture) <= now).OrderByDescending(x => x)
                    .FirstOrDefault();
                break;
            case "07":
                nextCycle = userConfig?.Hour.FirstOrDefault();
                break;
            case "08":
                nextCycle = userConfig?.Day.FirstOrDefault();
                break;
            case "09":
                nextCycle = userConfig?.Date.FirstOrDefault();
                break;
        }

        if (!string.IsNullOrEmpty(nextCycle)) nextCycle = $"{nextCycle} - saat ini";

        return nextCycle;
    }
}