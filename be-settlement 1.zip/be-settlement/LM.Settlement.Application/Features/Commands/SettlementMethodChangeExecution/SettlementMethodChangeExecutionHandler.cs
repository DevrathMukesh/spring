using LivinMerchant.General.Base.Exceptions;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Application.Contracts.Infrastructure.Mti;
using LM.Settlement.Application.Dtos.Request;
using LM.Settlement.Domain.Models.Data.Settlement;
using LM.Settlement.Domain.Models.System;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.Globalization;

namespace LM.Settlement.Application.Features.Commands.SettlementMethodChangeExecution;

public class SettlementMethodChangeExecutionHandler : IRequestHandler<SettlementMethodChangeExecutionCommand,
    SettlementMethodChangeExecutionResponse>
{
    private readonly IYokkeApi _yokkeApi;
    private readonly IConfigRepository _configRepository;
    private readonly ISettlementChangeStageRepository _settlementChangeStageRepository;
    private readonly ISettlementChangeRepository _settlementChangeRepository;
    private readonly IMtiRequestsRepository _imtiRequestsRepository;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly IVerificationPinRepository _verificationPinRepository;

    public SettlementMethodChangeExecutionHandler(
        IHttpContextAccessor httpContextAccessor, ISettlementChangeStageRepository settlementChangeStageRepository,
        IYokkeApi yokkeApi, IConfigRepository configRepository,
        ISettlementChangeRepository settlementChangeRepository, IMtiRequestsRepository imtiRequestsRepository,
        IConfiguration configuration, IVerificationPinRepository verificationPinRepository)
    {
        _httpContextAccessor = httpContextAccessor;
        _settlementChangeStageRepository = settlementChangeStageRepository;
        _yokkeApi = yokkeApi;
        _configRepository = configRepository;
        _settlementChangeRepository = settlementChangeRepository;
        _imtiRequestsRepository = imtiRequestsRepository;
        _verificationPinRepository = verificationPinRepository;
    }

    public async Task<SettlementMethodChangeExecutionResponse> Handle(
        SettlementMethodChangeExecutionCommand request,
        CancellationToken cancellationToken)
    {
        #region HttpContextItem

        var userId = Guid.Parse(_httpContextAccessor.HttpContext.Items["UserId"] as string ?? string.Empty);
        var storeId = Guid.Parse(_httpContextAccessor.HttpContext.Items["StoreId"] as string ?? string.Empty);
        var outletId = Guid.Parse(_httpContextAccessor.HttpContext.Items["OutletId"] as string ?? string.Empty);
        var isAccountOwner = bool.Parse(_httpContextAccessor.HttpContext.Items["IsAccountOwner"] as string ?? "false");

        #endregion

        var response = new SettlementMethodChangeExecutionResponse();

        var requestEpinStatus = _verificationPinRepository.GetQueryable<VerificationPin>()
            .Where(vp => vp.UserId == userId.ToString()
                         && vp.ServiceCode == "methodchange-settlement"
                         && vp.TransactionId == request.TransactionId.ToString()
                         && vp.Status == "VERIFIED"
                         && !vp.IsDeleted)
            .OrderByDescending(vp => vp.CreatedDate)
            .FirstOrDefault();

        if (requestEpinStatus == null)
        {
            response.ResponseCode = "22";
            response.ResponseMessage = "Verification Failed";
            return response;
        }

        var settlementConfig =
            (from c in await _configRepository.GetFromRedis()
                where c.ParameterKey == "settlement.MTI.requestMaxRetry"
                select new
                {
                    c.ParameterKey,
                    c.ParameterValue
                }
            ).ToList();

        var requestMaxRetryConfigString = settlementConfig
            .FirstOrDefault(x => x.ParameterKey == "settlement.MTI.requestMaxRetry")?.ParameterValue;

        var requestMaxRetryConfigInt = string.IsNullOrEmpty(requestMaxRetryConfigString)
            ? 3
            : int.Parse(requestMaxRetryConfigString);

        if (!isAccountOwner)
        {
            throw new UnauthorizedException("Unauthorized");
        }

        var getTokenDetail = (from s in _settlementChangeStageRepository.GetQueryable<SettlementChangeStage>()
            where s.TransactionId == request.TransactionId
                  && !s.IsDeleted && s.OutletId == outletId
                  && s.UserId == userId
                  && s.StoreId == storeId
                  && !s.IsUsed
            select s).FirstOrDefault();
        DateTime currentTime = DateTime.Now;

        if (getTokenDetail == null)
        {
            response.ResponseCode = "02";
            response.ResponseMessage = "Invalid Token";
            return response;
        }

        if (currentTime > getTokenDetail.ExpiryTime)
        {
            response.ResponseCode = "04";
            response.ResponseMessage = "Token Expired";
            return response;
        }

        if (getTokenDetail.Retry >= requestMaxRetryConfigInt)
        {
            response.ResponseCode = "05";
            response.ResponseMessage = "Token Expired";
            return response;
        }


        if (!(request.Action == "R" || string.IsNullOrEmpty(request.Action)))
        {
            throw new UnauthorizedException("Unauthorized");
        }

        var updateMtiRequest = new MtiRequests
        {
            StoreId = storeId,
            Status = "done",
            CreatedDate = DateTime.Now,
            Type = "settlement_change",
            OutletId = outletId
        };

        await _imtiRequestsRepository.CreateAsync(updateMtiRequest);

        var transactionId = updateMtiRequest.MtiRequestId;

        PostChangeSettlementTypeRequest postChangeSettlementTypeRequest = new PostChangeSettlementTypeRequest
        {
            TransactionDate = DateTime.Now.ToString("yyyyMMdd"),
            TransactionTime = DateTime.Now.ToString("HHmmss"),
            UserAppId = ((long)transactionId).ToBase36String(),
            StoreCode = getTokenDetail.StoreCode ?? string.Empty,
            SettlementType = getTokenDetail.NewType
        };

        int maxRetry = requestMaxRetryConfigInt;
        int retryAttempt = 0;
        bool isFailedUpdateTypeSettlement = false;

        while (retryAttempt <= maxRetry)
        {
            try
            {
                await _yokkeApi.UpdateTypeSettlement(postChangeSettlementTypeRequest);
                isFailedUpdateTypeSettlement = false;
                break;
            }
            catch (Exception)
            {
                isFailedUpdateTypeSettlement = true;
                retryAttempt++;
            }
        }

        if (isFailedUpdateTypeSettlement)
        {
            if (request.Action == "R")
            {
                getTokenDetail.Retry++;
                await _settlementChangeStageRepository.UpdateAsync(getTokenDetail);
            }

            response.TransactionId = getTokenDetail.TransactionId;
            response.ResponseCode = "01";
            response.ResponseMessage = "Mti request failed";
            return response;
        }

        var changesEffectiveDate = DateTime.Now.AddDays(1).Date;
        var formattedChangesEffectiveDate =
            changesEffectiveDate.ToString("dd MMM yyyy, HH:mm", new CultureInfo("id-ID")) + " WIB";

        var settlementChangeLog = (from sci in _settlementChangeRepository.GetQueryable<SettlementChange>()
            where sci.OutletId == outletId
                  && !sci.IsDeleted && sci.ChangesDate.Date == DateTime.Now.Date
            orderby sci.ChangesDate descending
            select sci).FirstOrDefault();

        if (settlementChangeLog != null)
        {
            settlementChangeLog.IsDeleted = true;
            await _settlementChangeRepository.UpdateAsync(settlementChangeLog);
        }

        var updateSettlementChange = new SettlementChange
        {
            SettlementChangeId = Guid.NewGuid(),
            OutletId = outletId,
            StoreId = storeId,
            UserId = userId,
            OldType = getTokenDetail.OldType ?? "",
            NewType = getTokenDetail.NewType,
            ChangesDate = DateTime.Now,
            ChangesEffectiveDate = changesEffectiveDate,
            IsActive = false,
            StoreCode = getTokenDetail.StoreCode ?? "",
            UserAppId = ((long)transactionId).ToBase36String(),
        };

        await _settlementChangeRepository.CreateAsync(updateSettlementChange);

        getTokenDetail.IsUsed = true;
        await _settlementChangeStageRepository.UpdateAsync(getTokenDetail);

        requestEpinStatus.IsDeleted = true;
        await _verificationPinRepository.UpdateAsync(requestEpinStatus);

        response.SettlementType = getTokenDetail.NewType;
        response.ChangesEffectiveDate = formattedChangesEffectiveDate;
        response.ResponseCode = "00";
        response.ResponseMessage = "Success";

        response.TransactionId = getTokenDetail.TransactionId;
        response.OutletId = outletId;

        return response;
    }
}