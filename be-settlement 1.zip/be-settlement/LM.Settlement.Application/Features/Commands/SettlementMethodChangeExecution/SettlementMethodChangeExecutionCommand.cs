using MediatR;

namespace LM.Settlement.Application.Features.Commands.SettlementMethodChangeExecution;

public class SettlementMethodChangeExecutionCommand : IRequest<SettlementMethodChangeExecutionResponse>
{
    public Guid TransactionId { get; set; }
    public string? PinHash { get; set; } = string.Empty;
    public string? Action { get; set; } = string.Empty;
}