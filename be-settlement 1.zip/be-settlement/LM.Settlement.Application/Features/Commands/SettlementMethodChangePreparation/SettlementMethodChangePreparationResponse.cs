using System.Text.Json.Serialization;

namespace LM.Settlement.Application.Features.Commands.SettlementMethodChangePreparation;

public class SettlementMethodChangePreparationResponse
{
    public string ResponseCode { get; set; } = string.Empty;
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public Guid OutletId { get; set; }
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public Guid TransactionId { get; set; }
}