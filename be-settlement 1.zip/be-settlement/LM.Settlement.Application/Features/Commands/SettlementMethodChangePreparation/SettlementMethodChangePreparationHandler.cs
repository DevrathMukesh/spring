using System.Globalization;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Application.Contracts.Infrastructure.ISeller;
using LM.Settlement.Domain.Models.Data.Settlement;
using LM.Settlement.Domain.Models.Surrounding.ISeller;
using MediatR;
using Microsoft.AspNetCore.Http;

namespace LM.Settlement.Application.Features.Commands.SettlementMethodChangePreparation;

public class SettlementMethodChangePreparationHandler : IRequestHandler<SettlementMethodChangePreparationCommand,
    SettlementMethodChangePreparationResponse>
{
    private readonly IiSellerApi _iSellerApi;
    private readonly IConfigRepository _configRepository;
    private readonly ISettlementChangeStageRepository _settlementChangeStageRepository;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public SettlementMethodChangePreparationHandler(
        IHttpContextAccessor httpContextAccessor, ISettlementChangeStageRepository settlementChangeStageRepository,
        IiSellerApi iSellerApi, IConfigRepository configRepository)
    {
        _httpContextAccessor = httpContextAccessor;
        _settlementChangeStageRepository = settlementChangeStageRepository;
        _iSellerApi = iSellerApi;
        _configRepository = configRepository;
    }

    public async Task<SettlementMethodChangePreparationResponse> Handle(
        SettlementMethodChangePreparationCommand request,
        CancellationToken cancellationToken)
    {
        var response = new SettlementMethodChangePreparationResponse();

        var configs =
            (from c in await _configRepository.GetFromRedis()
                where c.ParameterKey == "settlement.methodChange.maxTime"
                      || c.ParameterKey == "settlement.token.expiredTime"
                select c).ToList();

        var expiredTimeConfig = configs.FirstOrDefault(x => x.ParameterKey == "settlement.token.expiredTime")
            ?.ParameterValue;
        var maxTimeConfig = configs.FirstOrDefault(x => x.ParameterKey == "settlement.methodChange.maxTime")
            ?.ParameterValue ?? "23:50";

        var maxTime = DateTime.ParseExact(maxTimeConfig, "HH:mm", CultureInfo.InvariantCulture);

        var currentTime = DateTime.Now.TimeOfDay;

        if (maxTime <= DateTime.Now && currentTime <= TimeSpan.FromHours(24))
        {
            response.ResponseCode = "06";
            return response;
        }

        GetOutletSettlementTypeResponse outletSettlementType = await _iSellerApi.GetOutletSettlementType();

        var transactionId = Guid.NewGuid();
        var userId = Guid.Parse(_httpContextAccessor.HttpContext.Items["UserId"] as string ?? string.Empty);
        var storeId = Guid.Parse(_httpContextAccessor.HttpContext.Items["StoreId"] as string ?? string.Empty);
        var outletId = Guid.Parse(_httpContextAccessor.HttpContext.Items["OutletId"] as string ?? string.Empty);

        var insertSettlementChangeStage = new SettlementChangeStage
        {
            TransactionId = transactionId,
            UserId = userId,
            StoreId = storeId,
            OutletId = outletId,
            OldType = outletSettlementType.SettlementType,
            NewType = request.SettlementType,
            ChangesDate = DateTime.Now,
            ChangesEffectiveDate = DateTime.Now.AddDays(1).Date,
            ExpiryTime = DateTime.Now.AddMinutes(Convert.ToDouble(expiredTimeConfig)),
            IsUsed = false,
            StoreCode = outletSettlementType.StoreCode
        };
        await _settlementChangeStageRepository.CreateAsync(insertSettlementChangeStage);

        response.ResponseCode = "00";
        response.OutletId = outletId;
        response.TransactionId = transactionId;

        return response;
    }
}
