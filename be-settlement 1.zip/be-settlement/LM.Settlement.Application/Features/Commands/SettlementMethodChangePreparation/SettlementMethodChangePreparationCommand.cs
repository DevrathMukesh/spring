using MediatR;

namespace LM.Settlement.Application.Features.Commands.SettlementMethodChangePreparation;

public class SettlementMethodChangePreparationCommand : IRequest<SettlementMethodChangePreparationResponse>
{
    public string SettlementType { get; set; } = string.Empty;
}