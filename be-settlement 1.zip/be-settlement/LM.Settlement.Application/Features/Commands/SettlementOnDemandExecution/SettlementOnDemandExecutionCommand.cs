using MediatR;

namespace LM.Settlement.Application.Features.Commands.SettlementOnDemandExecution;

public class SettlementOnDemandExecutionCommand : IRequest<SettlementOnDemandExecutionResponse>
{
    public Guid TransactionId { get; set; }
    public string PinHash { get; set; } = string.Empty;
}