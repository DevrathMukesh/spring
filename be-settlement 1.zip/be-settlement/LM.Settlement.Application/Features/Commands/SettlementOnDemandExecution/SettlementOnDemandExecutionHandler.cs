using System.Globalization;
using LivinMerchant.General.Base.Exceptions;
using LM.Settlement.Application.Constant;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Application.Contracts.Infrastructure.Mti;
using LM.Settlement.Application.Dtos.Request;
using LM.Settlement.Domain.Models.Data.Settlement;
using LM.Settlement.Domain.Models.Surrounding.Yokke;
using LM.Settlement.Domain.Models.System;
using MediatR;
using Microsoft.AspNetCore.Http;

namespace LM.Settlement.Application.Features.Commands.SettlementOnDemandExecution;

public class SettlementOnDemandExecutionHandler : IRequestHandler<SettlementOnDemandExecutionCommand,
    SettlementOnDemandExecutionResponse>
{
    private readonly IYokkeApi _yokkeApi;
    private readonly IConfigRepository _configRepository;
    private readonly IDisbursementStageRepository _disbursementStageRepository;
    private readonly IDisbursementTrxRepository _disbursementTrxRepository;
    private readonly IMtiRequestsRepository _imtiRequestsRepository;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly IVerificationPinRepository _verificationPinRepository;
    private const string DateTimeFormat = CommonConstant.Format.DateTime;

    public SettlementOnDemandExecutionHandler(IHttpContextAccessor httpContextAccessor,
        IDisbursementStageRepository disbursementStageRepository, IYokkeApi yokkeApi,
        IConfigRepository configRepository, IDisbursementTrxRepository disbursementTrxRepository,
        IMtiRequestsRepository imtiRequestsRepository, IVerificationPinRepository verificationPinRepository)
    {
        _httpContextAccessor = httpContextAccessor;
        _disbursementStageRepository = disbursementStageRepository;
        _yokkeApi = yokkeApi;
        _configRepository = configRepository;
        _disbursementTrxRepository = disbursementTrxRepository;
        _imtiRequestsRepository = imtiRequestsRepository;
        _verificationPinRepository = verificationPinRepository;
    }

    public async Task<SettlementOnDemandExecutionResponse> Handle(
        SettlementOnDemandExecutionCommand request,
        CancellationToken cancellationToken)
    {
        #region HttpContextItem

        var userId = Guid.Parse(_httpContextAccessor.HttpContext.Items["UserId"] as string ?? string.Empty);
        var storeId = Guid.Parse(_httpContextAccessor.HttpContext.Items["StoreId"] as string ?? string.Empty);
        var outletId = Guid.Parse(_httpContextAccessor.HttpContext.Items["OutletId"] as string ?? string.Empty);

        #endregion

        var response = new SettlementOnDemandExecutionResponse();

        var timeoutMaxConfig =
            (from c in await _configRepository.GetFromRedis()
                where c.ParameterKey == "settlement.MTI.requestMaxRetry"
                select c.ParameterValue
            ).FirstOrDefault();

        int requestMaxRetryConfigInt = int.TryParse(timeoutMaxConfig, out var result) ? result : 3;

        var isAccountOwner = bool.Parse(_httpContextAccessor.HttpContext.Items["IsAccountOwner"] as string ?? "false");

        if (!isAccountOwner)
        {
            throw new UnauthorizedException("unauthorized");
        }

        var getTokenDetail = (from ds in _disbursementStageRepository.GetQueryable<DisbursementStage>()
            where ds.TransactionId == request.TransactionId
                  && !ds.IsDeleted && ds.OutletId == outletId
                  && ds.UserId == userId
                  && ds.StoreId == storeId
                  && !ds.IsUsed
            select ds).FirstOrDefault();

        if (getTokenDetail == null)
        {
            response.ResponseCode = "07";
            response.ResponseMessage = "Invalid Token";
            response.TransactionId = request.TransactionId;
            response.CreatedTime = DateTime.Now.ToString(DateTimeFormat);
            return response;
        }

        DateTime currentTime = DateTime.Now;

        if (currentTime > getTokenDetail.ExpiryTime)
        {
            response.ResponseCode = "02";
            response.ResponseMessage = "Token Expired";
            response.WithdrawalAmount = getTokenDetail.WithdrawalAmount;
            response.CreatedTime = DateTime.Now.ToString(DateTimeFormat);
            response.TransactionId = getTokenDetail.TransactionId;
            response.DisbursementRef = getTokenDetail.DisbursementRef;
            return response;
        }

        var requestEpinStatus = _verificationPinRepository.GetQueryable<VerificationPin>()
            .Where(vp => vp.UserId == userId.ToString()
                         && vp.ServiceCode == "ondemand-settlement"
                         && vp.TransactionId == request.TransactionId.ToString()
                         && vp.Status == "VERIFIED"
                         && !vp.IsDeleted)
            .OrderByDescending(vp => vp.CreatedDate)
            .FirstOrDefault();

        if (requestEpinStatus == null)
        {
            response.ResponseCode = "22";
            response.ResponseMessage = "Verification Failed";
            response.TransactionId = request.TransactionId;
            response.WithdrawalAmount = getTokenDetail.WithdrawalAmount;
            response.CreatedTime = DateTime.Now.ToString(DateTimeFormat);
            response.TransactionId = getTokenDetail.TransactionId;
            response.DisbursementRef = getTokenDetail.DisbursementRef;
            return response;
        }

        requestEpinStatus.IsDeleted = true;
        await _verificationPinRepository.UpdateAsync(requestEpinStatus);


        var newMtiRequest = new MtiRequests
        {
            StoreId = storeId,
            Status = "done",
            CreatedDate = DateTime.UtcNow,
            Type = "on_demand",
            OutletId = outletId
        };

        await _imtiRequestsRepository.CreateAsync(newMtiRequest);

        var transactionId = newMtiRequest.MtiRequestId;
        var transactionDate = DateTime.Now.ToString("yyyyMMdd");

        DisbursementOnDemandRequest disbursementOnDemandRequest = new DisbursementOnDemandRequest
        {
            TransactionDate = transactionDate,
            TransactionTime = DateTime.Now.ToString("HHmmss"),
            UserAppId = ((long)newMtiRequest.MtiRequestId).ToBase36String(),
            StoreCode = getTokenDetail.StoreCode,
            Amount = getTokenDetail.WithdrawalAmount.ToString(CultureInfo.InvariantCulture),
            ReferenceNo = transactionDate + transactionId,
        };

        int maxRetry = requestMaxRetryConfigInt;
        int retryAttempt = 0;
        bool apiCallSuccess = false;
        DisbursementOnDemandResponse? disbursementOnDemandresponse = null;

        var insertOnDemand = new DisbursementTrx
        {
            TransactionId = Guid.NewGuid(),
            UserId = getTokenDetail.UserId,
            StoreId = getTokenDetail.StoreId,
            OutletId = getTokenDetail.OutletId,
            Gid = getTokenDetail.Gid,
            DisbursementRef = getTokenDetail.DisbursementRef,
            InquiryDatetime = getTokenDetail.InquiryDatetime,
            AvailableBalance = getTokenDetail.AvailableBalance,
            WithdrawalAmount = getTokenDetail.WithdrawalAmount,
            RemainAmount = getTokenDetail.AvailableBalance,
            SettlementType = getTokenDetail.SettlementType,
            OndemandType = getTokenDetail.OndemandType ?? "",
            StoreCode = getTokenDetail.StoreCode,
            UserAppId = disbursementOnDemandRequest.UserAppId,
            ReffNo = disbursementOnDemandRequest.ReferenceNo,
            Response = null,
            CountTrx = null,
            IsCompleted = false
        };

        await _disbursementTrxRepository.CreateAsync(insertOnDemand);

        while (retryAttempt <= maxRetry)
        {
            try
            {
                disbursementOnDemandresponse = await _yokkeApi.DisbursementOnDemand(disbursementOnDemandRequest);
                apiCallSuccess = true;
                break;
            }
            catch (Exception)
            {
                retryAttempt++;
                apiCallSuccess = false;
            }
        }

        if (!apiCallSuccess)
        {
            insertOnDemand.Response = "99";
            await _disbursementTrxRepository.UpdateAsync(insertOnDemand);
            response.ResponseCode = "01";
            response.ResponseMessage = "Mti request failed";
            response.WithdrawalAmount = getTokenDetail.WithdrawalAmount;
            response.CreatedTime = DateTime.Now.ToString(DateTimeFormat);
            response.TransactionId = getTokenDetail.TransactionId;
            response.DisbursementRef = getTokenDetail.DisbursementRef;
            return response;
        }

        getTokenDetail.IsUsed = true;
        await _disbursementStageRepository.UpdateAsync(getTokenDetail);

        if (disbursementOnDemandresponse != null && disbursementOnDemandresponse.ResponseCode == "68")
        {
            insertOnDemand.Response = disbursementOnDemandresponse.ResponseCode;
            await _disbursementTrxRepository.UpdateAsync(insertOnDemand);
            response.ResponseCode = "68";
            response.ResponseMessage = "MTI Request Time Out";
            response.WithdrawalAmount = getTokenDetail.WithdrawalAmount;
            response.CreatedTime = DateTime.Now.ToString(DateTimeFormat);
            response.TransactionId = getTokenDetail.TransactionId;
            response.DisbursementRef = getTokenDetail.DisbursementRef;

            return response;
        }

        response.ResponseCode = "00";
        response.WithdrawalAmount = getTokenDetail.WithdrawalAmount;
        response.CreatedTime = DateTime.Now.ToString(DateTimeFormat);
        response.TransactionId = getTokenDetail.TransactionId;
        response.DisbursementRef = getTokenDetail.DisbursementRef;
        response.ReffNo = disbursementOnDemandRequest.ReferenceNo;

        response.TransactionId = request.TransactionId;
        response.OutletId = outletId;

        return response;
    }
}