using System.Globalization;
using LivinMerchant.General.Base.Exceptions;
using LM.Settlement.Application.Constant;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.System;
using MediatR;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;

namespace LM.Settlement.Application.Features.Commands.PayoutPendingEvent;

public class PayoutPendingEventHandler : IRequestHandler<PayoutPendingEventCommand, PayoutPendingEventResponse>
{
    private readonly IPayoutPendingRepository _payoutPendingRepository;
    private readonly IConfiguration _configuration;
    private const string LivinData = CommonConstant.LivinData;

    public PayoutPendingEventHandler(IPayoutPendingRepository payoutPendingRepository, IConfiguration configuration)
    {
        _payoutPendingRepository = payoutPendingRepository;
        _configuration = configuration;
    }

    public async Task<PayoutPendingEventResponse> Handle(PayoutPendingEventCommand request,
        CancellationToken cancellationToken)
    {
        var path = _configuration["FileHandler:RootFolder"] ?? throw new NotFoundException("Path not found");
        var directory = path.Replace("@StoreId",
            request.StoreId.ToString().ToLower().Replace("-", ""));
        var filePath = directory + request.FileName;

        if (!File.Exists(filePath))
            return new PayoutPendingEventResponse { IsSuccess = false, Message = "File not found" };

        using var reader = new StreamReader(filePath);
        var fileContent = await reader.ReadToEndAsync(cancellationToken);

        if (string.IsNullOrWhiteSpace(fileContent))
            return new PayoutPendingEventResponse
            {
                IsSuccess = false
            };

        var jsonArray = JArray.Parse(fileContent);
        List<string> references = [];
        var payoutPending =
            (from pp in _payoutPendingRepository.GetQueryable<PayoutPending>()
                where pp.OutletId == request.OutletId && !pp.IsDeleted
                select pp).ToList();
        var payoutPendingReference = payoutPending.Select(x => x.Reference).ToList();
        List<PayoutPending> payoutPendings = [];

        foreach (var jToken in jsonArray)
        {
            var item = (JObject)jToken;
            string properties = item["Properties"]?.ToString() ?? string.Empty;
            if (string.IsNullOrEmpty(properties)) continue;
            JObject propertiesObj = JObject.Parse(properties);
            var paymentName = propertiesObj[LivinData]?["PaymentName"]?.ToString();
            string reference = propertiesObj[LivinData]?["Reference"]?.ToString() ??
                               string.Empty;
            if (string.IsNullOrEmpty(paymentName) || !paymentName.Contains("QRIS") || string.IsNullOrEmpty(reference) ||
                payoutPendingReference.Contains(reference)) continue;
            references.Add(reference);

            var pendingStatus = GeneratePendingStatus(propertiesObj[LivinData]?["PayoutScheduleType"]?.ToString());

            var settlementDate = DateTime.ParseExact(propertiesObj[LivinData]?["SettlementDate"]?.ToString()!,
                "yyyyMMdd", CultureInfo.InvariantCulture);
            var newPayoutPending = new PayoutPending
            {
                PayoutPendingId = Guid.NewGuid(),
                OutletId = request.OutletId,
                SettlementPeriod = "3",
                SettlementType = "05",
                SettlementDate = settlementDate,
                PendingStatus = pendingStatus,
                TransactionDate = DateTime.Parse(propertiesObj[LivinData]?["TransactionDateUtc"]?.ToString()!,
                    CultureInfo.InvariantCulture),
                PayoutAmount = ConvertToDecimal(item["PayoutAmount"]),
                TransactionAmount = ConvertToDecimal(item["TransactionAmount"]),
                PaymentName = propertiesObj[LivinData]?["PaymentName"]?.ToString() ??
                              string.Empty,
                Reference = reference,
                InvoiceNo = propertiesObj[LivinData]?["InvoiceNo"]?.ToString() ??
                            string.Empty,
                MdrPercentage = string.Empty,
                MdrFee = 0,
                SharingRevPercentage = string.Empty,
                SharingRevFee = ConvertToDecimal(item["SharingFee"]),
                ShippingFee = ConvertToDecimal(item["ShippingFee"]),
                InsuranceFee = 0,
                CreatedBy = "SYSTEM",
                ModifiedBy = "SYSTEM",
                CreatedDate = DateTime.UtcNow,
                ModifiedDate = DateTime.UtcNow
            };
            payoutPendings.Add(newPayoutPending);
        }

        if (payoutPendings.Count != 0)
            await _payoutPendingRepository.BulkInsertManyAsync(payoutPendings);

        var deletePayoutPendings =
            payoutPending.Where(x => !references.Contains(x.Reference)).ToList();
        if (deletePayoutPendings.Count == 0)
            return new PayoutPendingEventResponse { IsSuccess = true, Message = "Success" };

        deletePayoutPendings.ForEach(x => x.IsDeleted = true);
        await _payoutPendingRepository.UpdatedManyAsync(deletePayoutPendings);

        return new PayoutPendingEventResponse
        {
            IsSuccess = true,
            Message = "Success"
        };
    }

    private static string GeneratePendingStatus(string? payoutScheduleType)
    {
        return payoutScheduleType switch
        {
            "hold" => "limit",
            "error" => "inactive",
            _ => ""
        };
    }

    private static decimal ConvertToDecimal(JToken? token)
    {
        if (token == null || token.Type == JTokenType.Null || token.Type == JTokenType.Undefined)
            return 0;
        try
        {
            return token.Value<decimal>();
        }
        catch
        {
            return 0;
        }
    }
}