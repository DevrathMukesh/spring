using LM.Settlement.Application.Dtos.Event;
using MediatR;

namespace LM.Settlement.Application.Features.Commands.PayoutPendingEvent;

public class PayoutPendingEventCommand : ObjectPayoutPendingEvent, IRequest<PayoutPendingEventResponse>;

public class PayoutPendingEventResponse
{
    public bool IsSuccess { get; set; }
    public string? Message { get; set; }
}