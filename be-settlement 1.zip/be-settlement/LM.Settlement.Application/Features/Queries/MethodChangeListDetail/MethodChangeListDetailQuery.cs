using MediatR;

namespace LM.Settlement.Application.Features.Queries.MethodChangeListDetail;

public class MethodChangeListDetailQuery: IRequest<MethodChangeListDetailResponse>
{
    
}