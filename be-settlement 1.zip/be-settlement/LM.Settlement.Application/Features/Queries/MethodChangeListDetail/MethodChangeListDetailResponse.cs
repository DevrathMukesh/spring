using System.Text.Json.Serialization;
using LM.Settlement.Domain.Models.Surrounding.ISeller;

namespace LM.Settlement.Application.Features.Queries.MethodChangeListDetail;

public class MethodChangeListDetailResponse
{
    public string ResponseCode { get; set; } = string.Empty;
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string SettlementType { get; set; } = string.Empty;
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public SettlementTypeInformation CurrentSettlementTypeName { get; set; } = new();
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public List<SettlementTypeInformation> AvailableSettlementTypeName { get; set; } = [];
    public string? SelectedSettlementType { get; set; }
    public bool SettlementLabelRealTime { get; set; }
}