using System.Text.Json;
using System.Text.Json.Nodes;
using LivinMerchant.General.Base.Exceptions;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Application.Contracts.Infrastructure.ISeller;
using LM.Settlement.Domain.Models.Data.Settlement;
using LM.Settlement.Domain.Models.Surrounding.ISeller;
using MediatR;

namespace LM.Settlement.Application.Features.Queries.MethodChangeListDetail;

public class
    MethodChangeListDetailHandler : IRequestHandler<MethodChangeListDetailQuery, MethodChangeListDetailResponse>
{
    private readonly IiSellerApi _iSellerApi;
    private readonly ISettlementChangeRepository _settlementChangeRepository;
    private readonly IConfigRepository _configRepository;

    public MethodChangeListDetailHandler(IiSellerApi iSellerApi, ISettlementChangeRepository settlementChangeRepository,
        IConfigRepository configRepository)
    {
        _iSellerApi = iSellerApi;
        _settlementChangeRepository = settlementChangeRepository;
        _configRepository = configRepository;
    }

    public async Task<MethodChangeListDetailResponse> Handle(MethodChangeListDetailQuery request,
        CancellationToken cancellationToken)
    {
        List<Config> configs = await _configRepository.GetFromRedis();

        var settlementConfigs = (
            from c in configs
            where (c.ParameterKey == "settlementPriority" || c.ParameterKey == "settlement.labelRealTime") && !c.IsDeleted
            select c
        ).ToList();

        var settlementPriority =
            settlementConfigs.FirstOrDefault(c => c.ParameterKey == "settlementPriority")?.ParameterValue
            ?? throw new BadRequestException("settlementPriority config not found");

        var settlementLabel =
            settlementConfigs.FirstOrDefault(c => c.ParameterKey == "settlement.labelRealTime")?.ParameterValue
                .ToString() ?? throw new BadRequestException("LabelRealTime config not found");

        MethodChangeListDetailResponse response = new MethodChangeListDetailResponse();
        CheckUserOutletResponse validateOutlet = await _iSellerApi.CheckUserOutlets();
        if (validateOutlet.ResponseCode != "00")
        {
            throw new NotFoundException("Invalid Outlet Id");
        }

        GetOutletSettlementTypeResponse outletSettlementType = await _iSellerApi.GetOutletSettlementType();

        var newType = (from sc in _settlementChangeRepository.GetQueryable<SettlementChange>()
            where sc.OutletId == validateOutlet.OutletId && !sc.IsDeleted
            orderby sc.CreatedDate descending
            select sc.NewType).FirstOrDefault();

        var settlementPriorityList = JsonSerializer.Deserialize<JsonArray>(settlementPriority)!.ToList();

        List<SettlementTypeInformation> availableSettlementTypeNameResponse = new List<SettlementTypeInformation>();
        settlementPriorityList.ForEach(x =>
        {
            availableSettlementTypeNameResponse.Add(
                outletSettlementType.AvailableSettlementTypeName.First(a => a.Id == x?.ToString()));
        });

        response.ResponseCode = outletSettlementType.ResponseCode;
        response.SettlementType = outletSettlementType.SettlementType;
        response.CurrentSettlementTypeName = outletSettlementType.CurrentSettlementTypeName;
        response.AvailableSettlementTypeName = availableSettlementTypeNameResponse;
        response.SelectedSettlementType = newType;
        response.SettlementLabelRealTime = Convert.ToBoolean(settlementLabel);
        return response;
    }
}