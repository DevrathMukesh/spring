using LivinMerchant.General.Base.Exceptions;
using LM.Settlement.Application.Contracts.Infrastructure.Internal;
using LM.Settlement.Application.Contracts.Infrastructure.ISeller;
using LM.Settlement.Domain.Models.Surrounding.Internal;
using LM.Settlement.Domain.Models.Surrounding.ISeller;
using MediatR;
using Microsoft.AspNetCore.Http;

namespace LM.Settlement.Application.Features.Queries.TenantMerchantInquiry;

public class TenantMerchantInquiryHandler:IRequestHandler<TenantMerchantInquiryQuery, TenantMerchantInquiryResponse>
{
    private readonly IiSellerApi _iSellerApi;
    private readonly IBackofficeApi _backofficeApi;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public TenantMerchantInquiryHandler(IiSellerApi iSellerApi, IBackofficeApi backofficeApi, IHttpContextAccessor httpContextAccessor)
    {
        _iSellerApi = iSellerApi;
        _backofficeApi = backofficeApi;
        _httpContextAccessor = httpContextAccessor;
    }

    public async Task<TenantMerchantInquiryResponse> Handle(TenantMerchantInquiryQuery request, CancellationToken cancellationToken)
    {
        CheckUserOutletResponse validateOutlet = await _iSellerApi.CheckUserOutlets();
        if (validateOutlet.ResponseCode != "00")
        {
            throw new NotFoundException("Invalid Outlet Id");
        }
        Guid storeId = Guid.Parse(_httpContextAccessor.HttpContext.Items["StoreId"] as string ?? string.Empty);
        Guid outletId = Guid.Parse(_httpContextAccessor.HttpContext.Items["OutletId"] as string ?? string.Empty);
        TenantMerchantInquiryResponse response = await _backofficeApi.TenantMerchantInquiryBackoffice(new TenantMerchantInquiryRequest{StoreId = storeId, OutletId = outletId});
        return response;
    }
}