using System.Text.Json.Serialization;

namespace LM.Settlement.Application.Features.Queries.TenantMerchantInquiry;

public class TenantMerchantInquiryResponse
{
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string ResponseCode { get; set; } = string.Empty;
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string SettlementType { get; set; } = string.Empty;
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public MdrFee MdrFee { get; set; } = new();
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public List<DisabledPayment> DisabledPayments { get; set; } = [];
}

public class MdrFee
{
    public string Min { get; set; } = string.Empty;
    public string Max { get; set; } = string.Empty;
    public string Range { get; set; } = string.Empty;
}

public class DisabledPayment
{
    public string PaymentName { get; set; } = string.Empty;
    public int Id { get; set; }
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public List<int> PaymentGatewayServiceId { get; set; } = [];
}