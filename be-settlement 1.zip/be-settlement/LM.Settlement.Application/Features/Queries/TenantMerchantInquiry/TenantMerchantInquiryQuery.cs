using MediatR;

namespace LM.Settlement.Application.Features.Queries.TenantMerchantInquiry;

public class TenantMerchantInquiryQuery:IRequest<TenantMerchantInquiryResponse>
{
    
}