using LivinMerchant.General.Base.Exceptions;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Application.Contracts.Infrastructure.ISeller;
using LM.Settlement.Domain.Models.Data.Settlement;
using LM.Settlement.Domain.Models.Surrounding.ISeller;
using MediatR;
using Newtonsoft.Json;

namespace LM.Settlement.Application.Features.Queries.MethodChangeDetail;

public class
    MethodChangeDetailHandler : IRequestHandler<MethodChangeDetailQuery, MethodChangeDetailResponse>
{
    private readonly ISettlementChangeRepository _settlementChangeRepository;
    private readonly IConfigRepository _configRepository;
    private readonly IiSellerApi _iSellerApi;
    private readonly IMasterConfigRepository _masterConfigRepository;

    public MethodChangeDetailHandler(ISettlementChangeRepository settlementChangeRepository, IiSellerApi iSellerApi,
        IConfigRepository configRepository, IMasterConfigRepository masterConfigRepository)
    {
        _settlementChangeRepository = settlementChangeRepository;
        _iSellerApi = iSellerApi;
        _configRepository = configRepository;
        _masterConfigRepository = masterConfigRepository;
    }

    public async Task<MethodChangeDetailResponse> Handle(MethodChangeDetailQuery request,
        CancellationToken cancellationToken)
    {
        List<Config> configs = await _configRepository.GetFromRedis();

        var settlementConfigs = (
            from c in configs
            where (c.ParameterKey == "settlement.disbursementLimit" ||
                   c.ParameterKey == "settlement.labelQrisNewMethod") && !c.IsDeleted
            select c
        ).ToList();

        var disburseLimit =
            settlementConfigs.FirstOrDefault(c => c.ParameterKey == "settlement.disbursementLimit")?.ParameterValue
            ?? throw new BadRequestException("settlementPriority config not found");

        var labelQrisNewMethod =
            settlementConfigs.FirstOrDefault(c => c.ParameterKey == "settlement.labelQrisNewMethod")?.ParameterValue
                .ToString() ?? throw new BadRequestException("Config not found");

        CheckUserOutletResponse validateOutlet = await _iSellerApi.CheckUserOutlets();
        if (validateOutlet.ResponseCode != "00")
        {
            throw new NotFoundException("Invalid Outlet Id");
        }

        var livinMdrResponse = await _iSellerApi.GetLivinMdr();

        if (livinMdrResponse.MdrList == null || livinMdrResponse.MdrList.Count == 0)
        {
            throw new NotFoundException("No MDR found");
        }

        var mdr = livinMdrResponse.MdrList.FirstOrDefault(x => x.PaymentType == "qris_dinamis")?.Mdr;

        int cddStoreLevel = validateOutlet.Level;

        GetOutletSettlementTypeResponse outletSettlementType = await _iSellerApi.GetOutletSettlementType();
        var settlementTypeName = outletSettlementType.CurrentSettlementTypeName;

        var changesEffectiveDate = (
            from s in _settlementChangeRepository.GetQueryable<SettlementChange>()
            where s.OutletId == validateOutlet.OutletId && !s.IsDeleted
            orderby s.ChangesEffectiveDate descending
            select new
            {
                s.ChangesEffectiveDate,
                s.NewType
            }
        ).FirstOrDefault();


        string? newType = null;
        bool isNewType = changesEffectiveDate != null &&
                         outletSettlementType.SettlementType != changesEffectiveDate.NewType;

        if (isNewType)
        {
            var matchedConfigs = (
                from c in await _masterConfigRepository.GetFromRedis()
                where c.ConfigGroup == "settlement"
                      && c.Additional == changesEffectiveDate.NewType
                      && c.ConfigName == "settlementTitle"
                select c
            ).FirstOrDefault()?.ConfigValue;

            var configValueObject =
                JsonConvert.DeserializeAnonymousType(matchedConfigs ?? "{}", new { InfoBoxTitle = "" })?.InfoBoxTitle;
            newType = configValueObject;
        }

        MethodChangeDetailResponse response = new MethodChangeDetailResponse
        {
            ResponseCode = "00",
            DisbursementLimit = disburseLimit ?? "",
            Mdr = mdr ?? "",
            SettlementType = outletSettlementType.SettlementType,
            ChangesEffectiveDate =
                changesEffectiveDate?.ChangesEffectiveDate.Date,
            StoreLevel = cddStoreLevel,
            SettlementInfo = outletSettlementType.SettlementInfos
                .Select(x => new SettlementInfoMethodDetail
                {
                    Period = x.Period,
                    CompleteStatus = x.CompleteStatus,
                    CompleteTime = x.CompleteTime,
                    CompleteRangeTitle = x.CompleteRangeTitle,
                    CompleteRangeSubTitle = x.CompleteRangeSubTitle
                }).ToList(),
            CurrentSettlementTypeName = new CurrentSettlementTypeName
            {
                SettlementName = settlementTypeName.SettlementName,
                SettlementTypeHeaderTitle = settlementTypeName.SettlementTypeHeaderTitle,
                SettlementTypeHeaderSubTitle = settlementTypeName.SettlementTypeHeaderSubTitle
            },
            IsNewSettlementType = isNewType,
            NewType = newType,
            SettlementNewQRIS = Convert.ToBoolean(labelQrisNewMethod)
        };
        return response;
    }
}