using MediatR;

namespace LM.Settlement.Application.Features.Queries.MethodChangeDetail;

public class MethodChangeDetailQuery : IRequest<MethodChangeDetailResponse>
{
}