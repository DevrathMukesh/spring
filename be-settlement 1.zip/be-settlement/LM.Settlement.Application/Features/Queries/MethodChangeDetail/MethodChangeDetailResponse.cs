using System.Text.Json.Serialization;

namespace LM.Settlement.Application.Features.Queries.MethodChangeDetail;

public class MethodChangeDetailResponse
{
    public string ResponseCode { get; set; } = string.Empty;
    public string DisbursementLimit { get; set; } = string.Empty;
    public string Mdr { get; set; } = string.Empty;
    public string SettlementType { get; set; } = string.Empty;
    public DateTime? ChangesEffectiveDate { get; set; }
    public int StoreLevel { get; set; }
    public List<SettlementInfoMethodDetail> SettlementInfo { get; set; } = [];
    public CurrentSettlementTypeName CurrentSettlementTypeName { get; set; } = new();
    public bool IsNewSettlementType { get; set; }
    public string? NewType { get; set; } 
    public bool SettlementNewQRIS { get; set; } 
}

public class SettlementInfoMethodDetail
{
    [JsonPropertyName("period")]
    public int Period { get; set; }
    [JsonPropertyName("completeStatus")]
    public string CompleteStatus { get; set; } = string.Empty;
    [JsonPropertyName("completeTime")]
    public string CompleteTime { get; set; } = string.Empty;
    [JsonPropertyName("completeRangeTitle")]
    public string CompleteRangeTitle { get; set; } = string.Empty;
    [JsonPropertyName("completeRangeSubTitle")]
    public string CompleteRangeSubTitle { get; set; } = string.Empty;
}

public class CurrentSettlementTypeName
{
    [JsonPropertyName("settlementName")]
    public string SettlementName { get; set; } = string.Empty;
    [JsonPropertyName("settlementTypeHeaderTitle")]
    public string SettlementTypeHeaderTitle { get; set; } = string.Empty;
    [JsonPropertyName("settlementTypeHeaderSubTitle")]
    public string SettlementTypeHeaderSubTitle { get; set; } = string.Empty;
}