namespace LM.Settlement.Application.Constant;

public static class ErrorConstant
{
    public static class ExceptionMessage
    {
        public const string InvalidRequest = "Invalid Request";
    }
}