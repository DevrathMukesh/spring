namespace LM.Settlement.Application.Constant;

public static class YokkeApiConstant
{
    public const string YokkeApi = nameof(YokkeApi);

    public static class Configuration
    {
        public const string TokenRequestorId = $"{YokkeApi}:TokenRequestorID";
        public const string SecretKey = $"{YokkeApi}:SecretKey";
        public const string ContentType = $"{YokkeApi}:ContentType";
        public const string ContentTypeJson = "application/json";
    }

    public static class Header
    {
        public const string Signature = "signature";
        public const string TokenRequestorId = "tokenRequestorID";
    }
}