namespace LM.Settlement.Application.Constant;

public static class CommonConstant
{
    public const string LoginInfo = nameof(LoginInfo);
    public const string Authorization = nameof(Authorization);
    public const string Bearer = nameof(Bearer);
    public const string LivinData = nameof(LivinData);

    public static class Format
    {
        public const string DateTime = "dd MMM yyyy, HH:mm";
    }

    
}