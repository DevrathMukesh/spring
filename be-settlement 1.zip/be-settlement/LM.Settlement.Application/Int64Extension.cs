namespace LM.Settlement.Application;

public static class Int64Extension
{
    private static readonly char[] BaseChars = 
        "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();

    public static string ToBase36String(this long value, int padding = 9)
    {
        long targetBase = BaseChars.Length;
        // Determine exact number of characters to use.
        char[] buffer = new char[Math.Max((int) Math.Ceiling(Math.Log(value + 1, targetBase)), 1)];

        var i = buffer.Length;
        do
        {
            buffer[--i] = BaseChars[value % targetBase];
            value /= targetBase;
        }
        while (value > 0);

        return new string(buffer, i, buffer.Length - i).PadLeft(padding, '0');
    }
}