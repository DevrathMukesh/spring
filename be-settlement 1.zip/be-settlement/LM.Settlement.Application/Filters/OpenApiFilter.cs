using System.Text;
using System.Text.RegularExpressions;
using LivinMerchant.General.Base.Exceptions;
using LM.Settlement.Application.Contracts.Infrastructure.Internal;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;

namespace LM.Settlement.Application.Filters;

public class OpenApiFilter : IAsyncActionFilter
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly IOpenApi _openApi;

    public OpenApiFilter(IHttpContextAccessor httpContextAccessor, IOpenApi openApi)
    {
        _httpContextAccessor = httpContextAccessor;
        _openApi = openApi;
    }

    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        var request = _httpContextAccessor.HttpContext.Request;
        request.EnableBuffering();
        var auth = request.Headers["Authorization"].ToString();
        var signature = request.Headers["X-SIGNATURE"].ToString();
        var timestamp = request.Headers["X-TIMESTAMP"].ToString();
        var endpointUrl = request.Path;

        if (string.IsNullOrEmpty(auth) || string.IsNullOrEmpty(signature) || string.IsNullOrEmpty(timestamp))
        {
            throw new UnauthorizedException("Invalid request");
        }

        string body;
        request.Body.Position = 0;
        using (var reader = new StreamReader(request.Body, Encoding.UTF8, true, 1024, true))
        {
            body = await reader.ReadToEndAsync();
        }

        request.Body.Position = 0;

        try
        {
            await _openApi.ValidateRequest(auth, signature, timestamp,
                Regex.Replace(body, "(\"(?:[^\"\\\\]|\\\\.)*\")|\\s+", "$1", RegexOptions.None,
                    TimeSpan.FromMilliseconds(200)), endpointUrl,
                _httpContextAccessor.HttpContext.Request.Method);
        }
        catch (Exception ex)
        {
            throw new UnauthorizedException(ex.Message);
        }

        await next();
    }
}