﻿using System.Reflection;
using LivinMerchant.Authorization.Services;
using LivinMerchant.Firebase.Services;
using LivinMerchant.Kafka.Services;
using LivinMerchant.Onboarding.Data.Services.OnboardingData;
using LivinMerchant.Onboarding.System.Services;
using LivinMerchant.Redis;
using Microsoft.Extensions.DependencyInjection;

namespace LM.Settlement.Application
{
    public static class ApplicationServiceRegistration
    {
        public static IServiceCollection AddApplicationServices(this IServiceCollection services)
        {
            services.AddTransient<IAuthorizationService, AuthorizationService>();
            services.AddMediatR(configuration =>
                configuration.RegisterServicesFromAssemblies(Assembly.GetExecutingAssembly()));
            services.AddScoped<IPushNotificationService, PushNotificationService>();
            services.AddScoped<IOnboardingDataService, OnboardingDataService>();
            services.AddScoped<IOnboardingSystemService, OnboardingSystemService>();
            services.AddSingleton<IProducerService, ProducerService>();

            services.AddRedisService();

            return services;
        }
    }
}