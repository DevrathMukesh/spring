using LivinMerchant.General.Base.Class.Repository;
using LM.Settlement.Domain.Models;
using LM.Settlement.Domain.Models.Data;

namespace LM.Settlement.Application.Contracts
{
    public interface IMasterConfigRepository : IGenericRepository<MasterConfig>
    {
        Task<List<MasterConfig>> GetFromRedis();
    }
}