using LivinMerchant.General.Base.Class.Repository;
using LM.Settlement.Domain.Models.System;

namespace LM.Settlement.Application.Contracts;

public interface IPayoutsRepository : IGenericRepository<Payouts>
{
    public Task<int> UpdatePayouts(Payouts instance);
}