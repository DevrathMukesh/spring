using LM.Settlement.Application.Dtos.Request;
using LM.Settlement.Application.Dtos.Response;
using LM.Settlement.Domain.Models.Surrounding.Yokke;

namespace LM.Settlement.Application.Contracts.Infrastructure.Mti;

public interface IYokkeApi
{
    Task<PostChangeSettlementTypeResponse> UpdateTypeSettlement(PostChangeSettlementTypeRequest request);
    Task<PostInquiryDisbursementResponse> InquiryDisbursement(PostInquiryDisbursementRequest request);
    Task<PostInquiryOnDemandResponse> InquiryOnDemand(PostInquiryOnDemandRequest request);
    Task<DisbursementOnDemandResponse> DisbursementOnDemand(DisbursementOnDemandRequest request);
}