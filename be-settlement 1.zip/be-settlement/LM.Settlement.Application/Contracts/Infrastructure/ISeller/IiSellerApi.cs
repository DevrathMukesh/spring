using LM.Settlement.Domain.Models.Surrounding.ISeller;

namespace LM.Settlement.Application.Contracts.Infrastructure.ISeller;

public interface IiSellerApi
{
    Task<CheckUserOutletResponse> CheckUserOutlets();
    Task<GetOutletSettlementTypeResponse> GetOutletSettlementType();
    Task<GetLivinMdrResponse> GetLivinMdr();
    Task<GetPayoutOndemandResponse> GetPayoutOndemand();
}