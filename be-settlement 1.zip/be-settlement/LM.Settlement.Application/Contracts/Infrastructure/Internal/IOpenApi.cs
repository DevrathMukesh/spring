namespace LM.Settlement.Application.Contracts.Infrastructure.Internal;

public interface IOpenApi
{
    Task<string> GetSignature(string password, string message, string auth);
    Task<string> GetToken(string signature, string timestamp, string clientKey);
    Task<string> GetHmac(string httpMethod, string endPointUrl, string accessToken, string reqBody, string timestamp);
    Task<string> GetHmacSignature(string postMessage, string clientSecret);
    Task<string> ValidateRequest(string auth, string signature, string timestamp, string payload, string path,
        string method);
}