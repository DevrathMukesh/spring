using LM.Settlement.Application.Features.Queries.TenantMerchantInquiry;
using LM.Settlement.Domain.Models.Surrounding.Internal;

namespace LM.Settlement.Application.Contracts.Infrastructure.Internal;

public interface IBackofficeApi
{
    Task<TenantMerchantInquiryResponse> TenantMerchantInquiryBackoffice(TenantMerchantInquiryRequest request);
}