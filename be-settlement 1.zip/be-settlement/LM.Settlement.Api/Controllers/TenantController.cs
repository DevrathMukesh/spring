using LivinMerchant.General.Base.Filter;
using LM.Settlement.Application.Features.Queries.TenantMerchantInquiry;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace LM.Settlement.Api.Controllers;
[ServiceFilter(typeof(AuthFilter))]
[Route("api/settlement/v1/[Controller]")]
public class TenantController: BaseController
{
    private readonly IMediator _mediator;

    public TenantController(IMediator mediator)
    {
        _mediator = mediator;
    }

    [HttpPost("inquiry")]
    public async Task<IActionResult> SettlementOnDemandStatus()
    {
        var result = await _mediator.Send(new TenantMerchantInquiryQuery());
        return Ok(result);
    }
}