﻿using Microsoft.AspNetCore.Mvc;

namespace LM.Settlement.Api.Controllers;

[ApiController]
[Route("api")]
public class BaseController : ControllerBase
{
    [NonAction]
    public OkObjectResult OkResponse(object value)
    {
        return new OkObjectResult(value);
    }

    [NonAction]
    public NotFoundObjectResult NotFoundResponse(object value)
    {
        return new NotFoundObjectResult(value);
    }

    [NonAction]
    public BadRequestObjectResult BadRequestObjectResult(object value)
    {
        return new BadRequestObjectResult(value);
    }
}