using LM.Settlement.Application.Features.Commands.Oauth2.GetHmac;
using LM.Settlement.Application.Features.Commands.Oauth2.GetHmacSignature;
using LM.Settlement.Application.Features.Commands.Oauth2.GetSignature;
using LM.Settlement.Application.Features.Commands.Oauth2.GetToken;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace LM.Settlement.Api.Controllers;

public class OpenApiController : BaseController
{
    private readonly IMediator _mediator;

    public OpenApiController(IMediator mediator)
    {
        _mediator = mediator;
    }

    [HttpPost("v1/sign")]
    public async Task<IActionResult> GetSign(GetSignatureCommand request)
    {
        var result = await _mediator.Send(request);
        return Ok(result);
    }

    [HttpPost("v1/token")]
    public async Task<IActionResult> GetAccessToken(GetTokenCommand request)
    {
        var result = await _mediator.Send(request);
        return Ok(result);
    }

    [HttpPost("v1/gethmac")]
    public async Task<IActionResult> GetHmac(GetHmacCommand request)
    {
        var result = await _mediator.Send(request);
        return Ok(result);
    }

    [HttpPost("v1/hmacsignature")]
    public async Task<IActionResult> GetHmacSignature(GetHmacSignatureCommand request)
    {
        var result = await _mediator.Send(request);
        return Ok(result);
    }
}