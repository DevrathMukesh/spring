using LivinMerchant.General.Base.Filter;
using LM.Settlement.Application.Features.Commands.OnDemandBalanceInquiry;
using LM.Settlement.Application.Features.Commands.OnDemandPeparation;
using LM.Settlement.Application.Features.Commands.SettlementOnDemandExecution;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace LM.Settlement.Api.Controllers;

[Route("api/settlement/v1/[Controller]")]
public class OnDemandController : BaseController
{
    private readonly IMediator _mediator;

    public OnDemandController(IMediator mediator)
    {
        _mediator = mediator;
    }

    [ServiceFilter(typeof(AuthFilter))]
    [HttpPost("preparation")]
    public async Task<IActionResult> PreparationHandler([FromBody] OnDemandPeparationCommand request)
    {
        var result = await _mediator.Send(request);
        return Ok(result);
    }

    [ServiceFilter(typeof(AuthFilter))]
    [HttpPost("execution")]
    public async Task<IActionResult> SettlementOnDemandExecution(SettlementOnDemandExecutionCommand request)
    {
        var result = await _mediator.Send(request);
        return Ok(result);
    }

    [ServiceFilter(typeof(AuthFilter))]
    [HttpPost("balance-inquiry")]
    public async Task<IActionResult> BalanceInquiryHandler()
    {
        var result = await _mediator.Send(new OnDemandBalanceInquiryCommand());
        return Ok(result);
    }
}