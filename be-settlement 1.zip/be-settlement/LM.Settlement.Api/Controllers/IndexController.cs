﻿using LivinMerchant.General.Base.Helper;
using Microsoft.AspNetCore.Mvc;

namespace LM.Settlement.Api.Controllers;

[Route("api/[controller]")]
public class IndexController : Controller
{
    private readonly IConfiguration _configuration;

    public IndexController(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    // GET: api/values
    [HttpGet]
    public ResultMessage Get()
    {
        string envName = _configuration["AppSettings:AppName"] ?? "";
        var result = new ResultMessage();
        result.Message = $"Connected {envName}";
        return result;
    }

    public class ResultMessage
    {
        public string Message { get; set; } = "Connected 1";
    }
}