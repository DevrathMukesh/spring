using LivinMerchant.General.Base.Filter;
using LM.Settlement.Application.Features.Commands.MethodChangeStatus;
using LM.Settlement.Application.Features.Commands.SettlementMethodChangeExecution;
using LM.Settlement.Application.Features.Commands.SettlementMethodChangePreparation;
using LM.Settlement.Application.Features.Queries.MethodChangeDetail;
using LM.Settlement.Application.Features.Queries.MethodChangeListDetail;
using LM.Settlement.Application.Filters;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace LM.Settlement.Api.Controllers;

[Route("api/settlement/v1/method-change")]
public class MethodChangeController : BaseController
{
    private readonly IMediator _mediator;

    public MethodChangeController(IMediator mediator)
    {
        _mediator = mediator;
    }

    [ServiceFilter(typeof(AuthFilter))]
    [HttpPost("list-detail")]
    public async Task<IActionResult> MethodChangeListDetail()
    {
        var result = await _mediator.Send(new MethodChangeListDetailQuery());
        return Ok(result);
    }

    [ServiceFilter(typeof(AuthFilter))]
    [HttpPost("detail")]
    public async Task<IActionResult> SettlementMethodDetail()
    {
        var result = await _mediator.Send(new MethodChangeDetailQuery());
        return Ok(result);
    }

    [ServiceFilter(typeof(AuthFilter))]
    [HttpPost("preparation")]
    public async Task<IActionResult> SettlementMethodChangePreparation(SettlementMethodChangePreparationCommand request)
    {
        var result = await _mediator.Send(request);
        return Ok(result);
    }

    [ServiceFilter(typeof(AuthFilter))]
    [HttpPost("execution")]
    public async Task<IActionResult> SettlementMethodChangeExecution(SettlementMethodChangeExecutionCommand request)
    {
        var result = await _mediator.Send(request);
        return Ok(result);
    }

    [ServiceFilter(typeof(OpenApiFilter))]
    [HttpPost("status")]
    public async Task<IActionResult> SettlementMethodChangeStatus(MethodChangeStatusCommand request)
    {
        var result = await _mediator.Send(request);
        return Ok(result);
    }
}