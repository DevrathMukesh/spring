using FirebaseAdmin;
using Google.Apis.Auth.OAuth2;
using LivinMerchant.General.Base.Filter;
using LivinMerchant.General.Base.Helper;
using LivinMerchant.General.Base.Middleware;
using LivinMerchant.Onboarding.Data;
using LivinMerchant.Onboarding.System;
using LM.Settlement.Application;
using LM.Settlement.Application.Filters;
using LM.Settlement.Infrastructure;
using LM.Settlement.Persistence;
using KafkaOptions = LM.Settlement.Application.Options.KafkaOptions;

var envName = Settings.AppSettingValue("BaseUrl", "SettlementUrl", "");
var headerFilter = Settings.AppSettingValue("HeaderFilter", "isFilter");
var appKeyFirebase = Tools.Decrypt(Settings.AppSettingValue("AppKeys", "FirebaseKey", ""),
    Settings.AppSettingValue("appSettings", "ApiKey", ""));

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddHttpContextAccessor();
builder.Services.AddTransient<AuthFilter>();
builder.Services.AddTransient<OpenApiFilter>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddOnboardingSystemContext(builder.Configuration);
builder.Services.AddOnboardingDataContext(builder.Configuration);
builder.Services.AddApplicationServices();
builder.Services.AddInfrastructureServices(builder.Configuration);
builder.Services.AddPersistenceSystemService();
builder.Services.AddPersistenceSettlementService();
builder.Services.AddPersistenceDataService();
builder.Services.AddOptions<KafkaOptions>().Bind(builder.Configuration.GetSection("Kafka"));

builder.Services.AddControllers();

builder.Services.AddCors(options =>
{
    options.AddPolicy("all", corsPolicyBuilder => corsPolicyBuilder
        .AllowAnyHeader()
        .AllowAnyMethod()
        .SetIsOriginAllowed(_ => true)
        .WithOrigins(envName)
    );
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

if (FirebaseApp.DefaultInstance == null)
{
    FirebaseApp.Create(new AppOptions()
    {
        Credential = GoogleCredential.FromJson(appKeyFirebase)
    });
}

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseMiddleware<RequestMiddleware>();
app.UseMiddleware<ResponseWrapperMiddleware>();

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.Use(async (context, next) =>
{
    context.Response.Headers.Append("X-Frame-Options", "DENY");
    context.Response.Headers.Append("X-Xss-Protection", "1");
    context.Response.Headers.Append("X-Settlement-Type-Options", "nosniff");
    context.Response.Headers.Append("Settlement-Security-Policy",
        "default-src 'self' https: 'unsafe-inline' 'unsafe-eval'; img-src 'self' data: ;font-src 'self' data:;");
    context.Response.Headers.Append("Referrer-Policy", "no-referrer");
    context.Response.Headers.Append("X-Permitted-Cross-Domain-Policies", "none");

    context.Response.Headers.Append("access-control-allow-credentials", "true");
    context.Response.Headers.Append("access-control-allow-headers", "Authorization, Settlement-Type, Origin");
    context.Response.Headers.Append("access-control-allow-methods", "POST, PUT, GET, PATCH, DELETE");
    context.Response.Headers.Append("access-control-allow-origin", envName);
    context.Response.Headers.Append("access-control-max-age", "3600");

    context.Response.Headers.Append("Feature-Policy",
        "accelerometer 'none'; camera 'none'; geolocation 'none'; gyroscope 'none'; magnetometer 'none'; microphone 'none'; payment 'none'; usb 'none'");

    context.Response.Headers.Remove("Server");

    if (headerFilter == "true")
    {
        context.Response.Headers.Remove("X-CDN");
    }

    await next();
});

app.UseCors(options => options.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());

//bypass authorization and authentication
app.MapControllers().AllowAnonymous();

await app.RunAsync();