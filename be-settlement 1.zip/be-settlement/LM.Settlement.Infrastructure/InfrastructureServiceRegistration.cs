﻿using LivinMerchant.General.Base.Class.Logger;
using LivinMerchant.General.Base.Middleware.Models;
using LM.Settlement.Application.Contracts.Infrastructure.Internal;
using LM.Settlement.Application.Contracts.Infrastructure.ISeller;
using LM.Settlement.Application.Contracts.Infrastructure.Mti;
using LM.Settlement.Infrastructure.Surrounding.Internal;
using LM.Settlement.Infrastructure.Surrounding.ISeller;
using LM.Settlement.Infrastructure.Surrounding.MtiApi;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace LM.Settlement.Infrastructure;

public static class InfrastructureServicesRegistration
{
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddScoped<IAppLogger<LoggingEvent>, LoggerAdapter<LoggingEvent>>();
        services.AddScoped<IiSellerApi, ISellerApi>();
        services.AddScoped<IYokkeApi, YokkeApi>();
        services.AddScoped<IBackofficeApi, BackofficeApi>();
        services.AddScoped<IOpenApi, OpenApi>();
        return services;
    }
}