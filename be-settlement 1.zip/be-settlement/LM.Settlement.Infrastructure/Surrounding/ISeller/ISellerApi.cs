using LivinMerchant.General.Base.Exceptions;
using LM.Settlement.Application.Constant;
using LM.Settlement.Application.Contracts.Infrastructure.ISeller;
using LM.Settlement.Domain.Models.Surrounding.ISeller;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace LM.Settlement.Infrastructure.Surrounding.ISeller;

public class ISellerApi : BaseApi, IiSellerApi
{
    private readonly IConfiguration _configuration;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private const string LoginInfo = CommonConstant.LoginInfo;
    private const string Authorization = CommonConstant.Authorization;
    private const string InvalidRequest = ErrorConstant.ExceptionMessage.InvalidRequest;
    private readonly string? _baseUrl;

    public ISellerApi(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
    {
        _configuration = configuration;
        _httpContextAccessor = httpContextAccessor;
        _baseUrl = _configuration["BaseUrl:ISellerApiUrl"];
    }

    public async Task<CheckUserOutletResponse> CheckUserOutlets()
    {
        CheckUserOutletResponse result = new CheckUserOutletResponse();

        string checkUserOutletsUrl = _baseUrl + _configuration["CheckUserOutlet:ApiUrl"];
        string auth = _httpContextAccessor.HttpContext!.Request.Headers[Authorization].ToString();
        string loginInfo = _httpContextAccessor.HttpContext!.Request.Headers[LoginInfo].ToString();
        if (string.IsNullOrEmpty(auth) || string.IsNullOrEmpty(loginInfo))
        {
            throw new BadRequestException(InvalidRequest);
        }

        Dictionary<string, string> headers = new Dictionary<string, string>
        {
            { LoginInfo, loginInfo },
            { Authorization, auth }
        };
        var response = await Post(checkUserOutletsUrl, null, headers, null);

        if (string.IsNullOrEmpty(response)) return result;
        result = JsonConvert.DeserializeObject<BaseResponse<CheckUserOutletResponse>>(response)?.Result ??
                 new CheckUserOutletResponse();

        return result;
    }

    public async Task<GetOutletSettlementTypeResponse> GetOutletSettlementType()
    {
        GetOutletSettlementTypeResponse result = new GetOutletSettlementTypeResponse();

        string auth = _httpContextAccessor.HttpContext!.Request.Headers[Authorization].ToString();
        string loginInfo = _httpContextAccessor.HttpContext!.Request.Headers[LoginInfo].ToString();
        if (string.IsNullOrEmpty(auth) || string.IsNullOrEmpty(loginInfo))
        {
            throw new BadRequestException(InvalidRequest);
        }

        string checkUserOutletsUrl = _baseUrl + _configuration["GetOutletSettlementType:ApiUrl"];

        Dictionary<string, string> headers = new Dictionary<string, string>
        {
            { LoginInfo, loginInfo },
            { Authorization, auth }
        };
        var response = await Post(checkUserOutletsUrl, null, headers, null);

        if (string.IsNullOrEmpty(response)) return result;
        var getOutletSettlementTypeResponse =
            JsonConvert.DeserializeObject<BaseResponse<GetOutletSettlementTypeResponse>>(response)?.Result;
        if (getOutletSettlementTypeResponse != null)
            result = getOutletSettlementTypeResponse;

        return result;
    }

    public async Task<GetLivinMdrResponse> GetLivinMdr()
    {
        GetLivinMdrResponse result = new GetLivinMdrResponse();

        string auth = _httpContextAccessor.HttpContext!.Request.Headers[Authorization].ToString();
        string loginInfo = _httpContextAccessor.HttpContext!.Request.Headers[LoginInfo].ToString();
        if (string.IsNullOrEmpty(auth) || string.IsNullOrEmpty(loginInfo))
        {
            throw new BadRequestException(InvalidRequest);
        }

        string livinMdrUrl = _baseUrl + _configuration["GetMdr:ApiUrl"];

        Dictionary<string, string> headers = new Dictionary<string, string>
        {
            { LoginInfo, loginInfo },
            { Authorization, auth }
        };
        var response = await Get(livinMdrUrl, headers);

        if (string.IsNullOrEmpty(response)) return result;
        result = JsonConvert.DeserializeObject<GetLivinMdrResponse>(response) ??
                 new GetLivinMdrResponse();

        return result;
    }

    public async Task<GetPayoutOndemandResponse> GetPayoutOndemand()
    {
        GetPayoutOndemandResponse result = new GetPayoutOndemandResponse();

        string auth = _httpContextAccessor.HttpContext!.Request.Headers[Authorization].ToString();
        string loginInfo = _httpContextAccessor.HttpContext!.Request.Headers[LoginInfo].ToString();
        if (string.IsNullOrEmpty(auth) || string.IsNullOrEmpty(loginInfo))
        {
            throw new BadRequestException(InvalidRequest);
        }

        string getPayoutOnDemandUrl = _baseUrl + _configuration["GetPayoutOndemand:ApiUrl"];

        Dictionary<string, string> headers = new Dictionary<string, string>
        {
            { LoginInfo, loginInfo },
            { Authorization, auth }
        };
        var response = await Post(getPayoutOnDemandUrl, null, headers, null);

        if (string.IsNullOrEmpty(response)) return result;
        var getPayoutOnDemandUrlResponse =
            JsonConvert.DeserializeObject<BaseResponse<GetPayoutOndemandResponse>>(response)?.Result;
        if (getPayoutOnDemandUrlResponse != null)
            result = getPayoutOnDemandUrlResponse;
        return result;
    }
}