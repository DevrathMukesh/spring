using LM.Settlement.Application.Contracts.Infrastructure.Internal;
using Microsoft.Extensions.Configuration;

namespace LM.Settlement.Infrastructure.Surrounding.Internal;

public class OpenApi : IOpenApi
{
    private readonly string _baseUrl;
    private readonly string _content;
    private readonly string _clientName;
    private readonly string _bodyToken;
    private readonly IConfiguration _configuration;

    public OpenApi(IConfiguration configuration)
    {
        _configuration = configuration;
        _baseUrl = _configuration["BaseUrl:OpenApiUrl"] ?? "";
        _content = _configuration["OpenApi:ContentType"] ?? "";
        _clientName = _configuration["OpenApi:ClientName"] ?? "";
        _bodyToken = _configuration["OpenApi:BodyToken"] ?? "";
    }

    public async Task<string> GetHmac(string httpMethod, string endPointUrl, string accessToken, string reqBody,
        string timestamp)
    {
        string apiUrl = _configuration["OpenApi:GetHmac"] ?? "";
        var headers = new Dictionary<string, string>
        {
            ["HttpMethod"] = httpMethod,
            ["Path"] = endPointUrl,
            ["BearerToken"] = accessToken,
            ["ReqPayload"] = reqBody,
            ["TimeStamp"] = timestamp,
            ["X-CLIENT-NAME"] = _clientName
        };
        var response = await BaseApi.Post(_baseUrl + apiUrl, "{}", headers, new StringContent("{}", null, _content));

        return response;
    }

    public async Task<string> GetHmacSignature(string postMessage, string clientSecret)
    {
        string apiUrl = _configuration["OpenApi:GetHmacSignature"] ?? "";

        var headers = new Dictionary<string, string>
        {
            ["PostMessage"] = postMessage,
            ["ClientSecret"] = clientSecret
        };
        var response = await BaseApi.Post(_baseUrl + apiUrl, "{}", headers, new StringContent("{}", null, _content));

        return response;
    }

    public async Task<string> GetSignature(string password, string message, string auth)
    {
        string apiUrl = _configuration["OpenApi:GetSignature"] ?? "";

        var headers = new Dictionary<string, string>
        {
            ["KeyPassword"] = password,
            ["Message"] = message,
            ["Authorization"] = auth
        };
        var response = await BaseApi.Post(_baseUrl + apiUrl, "{}", headers, new StringContent("{}", null, _content));

        return response;
    }

    public async Task<string> GetToken(string signature, string timestamp, string clientKey)
    {
        string apiUrl = _configuration["OpenApi:GetToken"] ?? "";

        var headers = new Dictionary<string, string>
        {
            ["X-SIGNATURE"] = signature,
            ["X-TIMESTAMP"] = timestamp,
            ["X-CLIENT-KEY"] = clientKey,
            ["X-CLIENT-NAME"] = _clientName,
        };
        var response = await BaseApi.Post(_baseUrl + apiUrl, _bodyToken, headers,
            new StringContent(_bodyToken, null, _content));

        return response;
    }

    public async Task<string> ValidateRequest(string auth, string signature, string timestamp, string payload,
        string path, string method)
    {
        string apiUrl = _configuration["OpenApi:ValidateRequest"] ?? "";

        var headers = new Dictionary<string, string>
        {
            ["Authorization"] = auth,
            ["X-SIGNATURE"] = signature,
            ["X-TIMESTAMP"] = timestamp,
            ["X-CLIENT-NAME"] = _clientName,
            ["X-PAYLOAD"] = payload,
            ["X-PATH"] = path,
            ["X-REQUEST-METHOD"] = method
        };
        var response = await BaseApi.Post(_baseUrl + apiUrl, "{}", headers, new StringContent("{}", null, _content));

        return response;
    }
}