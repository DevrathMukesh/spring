using LivinMerchant.General.Base.Exceptions;
using LM.Settlement.Application.Contracts.Infrastructure.Internal;
using LM.Settlement.Application.Features.Queries.TenantMerchantInquiry;
using LM.Settlement.Domain.Models.Surrounding.Internal;
using LM.Settlement.Domain.Models.Surrounding.ISeller;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace LM.Settlement.Infrastructure.Surrounding.Internal;

public class BackofficeApi: BaseApi, IBackofficeApi
{
    private readonly IConfiguration _configuration;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public BackofficeApi(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
    {
        _configuration = configuration;
        _httpContextAccessor = httpContextAccessor;
    }

    public async Task<TenantMerchantInquiryResponse> TenantMerchantInquiryBackoffice(TenantMerchantInquiryRequest request)
    {
        TenantMerchantInquiryResponse result = new TenantMerchantInquiryResponse();

        var baseUrl = _configuration["BaseUrl:IBackofficeApiUrl"];
        string checkUserOutletsUrl = baseUrl + _configuration["TenantMerchantInquiry:ApiUrl"];
        string auth = _httpContextAccessor.HttpContext!.Request.Headers["Authorization"].ToString();
        string loginInfo = _httpContextAccessor.HttpContext!.Request.Headers["LoginInfo"].ToString();
        string content = _configuration["TenantMerchantInquiry:ContentType"] ?? "application/json";

        if (string.IsNullOrEmpty(auth) || string.IsNullOrEmpty(loginInfo))
        {
            throw new BadRequestException("Invalid request");
        }

        Dictionary<string, string> headers = new Dictionary<string, string>
        {
            { "LoginInfo", loginInfo },
            { "Authorization", auth }
        };
        var payload = JsonSerializer.Serialize(request);

        var response = await Post(checkUserOutletsUrl, null, headers, new StringContent(payload, null, content));

        if (string.IsNullOrEmpty(response)) return result;
        result = JsonConvert.DeserializeObject<BaseResponse<TenantMerchantInquiryResponse>>(response)?.Result ??
                 new TenantMerchantInquiryResponse();

        return result;
    }
}