using LivinMerchant.Redis.Services;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Application.Contracts.Infrastructure.Mti;
using LM.Settlement.Application.Dtos.Request;
using LM.Settlement.Application.Dtos.Response;
using LM.Settlement.Domain.Models.Surrounding.Yokke;
using Microsoft.Extensions.Configuration;
using System.Security.Cryptography;
using System.Text;
using LM.Settlement.Application.Constant;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace LM.Settlement.Infrastructure.Surrounding.MtiApi;

public interface IHasResponseCode
{
    string ResponseCode { get; set; }
    string ResponseMessage { get; set; }
}

public class YokkeApi : IYokkeApi
{
    private readonly IRedisService _redisService;
    private readonly IConfiguration _configuration;
    private readonly string _baseUrl;
    private const string Authorization = CommonConstant.Authorization;
    private const string Bearer = CommonConstant.Bearer + " ";


    public YokkeApi(IRedisService redisService, IConfiguration configuration)
    {
        _redisService = redisService;
        _configuration = configuration;
        _baseUrl = _configuration["BaseUrl:YokkeApi"] ?? "";
    }

    private static string HMAC_SHA512(string body, string password)
    {
        byte[] keyBytes = Encoding.UTF8.GetBytes(password);
        byte[] messageBytes = Encoding.UTF8.GetBytes(body);
        using var cryptographer = new HMACSHA512(keyBytes);
        var hash = cryptographer.ComputeHash(messageBytes);
        return ByteArrayToString(hash);
    }

    private static string ByteArrayToString(byte[] ba)
    {
        StringBuilder hex = new StringBuilder(ba.Length * 2);
        foreach (byte b in ba)
            hex.AppendFormat("{0:x2}", b);
        return hex.ToString();
    }

    private async Task<string> GetJwt()
    {
        var yokkeKey = _configuration["Redis:CacheKeys:YokkeAuth:Key"] ?? "YokkeAuthToken";
        var yokkeTimespan = Convert.ToInt32(_configuration["Redis:CacheKeys:YokkeAuth:TimeSpan"]);
        var yokkeAuthToken = await _redisService.GetAsync<string>(yokkeKey);
        if (!string.IsNullOrEmpty(yokkeAuthToken)) return yokkeAuthToken;

        string apiUrl = _configuration["YokkeApi:Jwt"] ?? "";
        string key = _configuration["YokkeApi:X-MTI-Key"] ?? "";
        string pass = _configuration["YokkeApi:X-MTI-Pass"] ?? "";
        string cookie = _configuration["YokkeApi:CookieJwt"] ?? "";
        string xtimestamp = DateTime.Now.ToString("yyyy-MM-dd HH\\:mm\\:ss");
        string signature = HMAC_SHA512($"{key}|{xtimestamp}", pass);

        Dictionary<string, string> headers = new()
        {
            { "X-MTI-Key", key },
            { "X-TIMESTAMP", xtimestamp },
            { "X-SIGNATURE", signature },
            { "Cookie", cookie }
        };

        string response = await BaseApi.Get(_baseUrl + apiUrl, headers);

        var res = JsonSerializer.Deserialize<YokkeJwtResponse>(response) ?? new YokkeJwtResponse();
        await _redisService.SetAsync(yokkeKey, res.Jwt, TimeSpan.FromMinutes(yokkeTimespan));
        return res.Jwt;
    }

    private async Task<TResponse> PostToYokke<TRequest, TResponse>(
        string apiUrlConfigKey,
        TRequest request,
        bool includeCookie = false,
        bool throwIfFailed = false)
        where TResponse : class, new()
    {
        string jwt = await GetJwt();
        string apiUrl = _configuration[apiUrlConfigKey] ?? "";
        string tokenRequestorId = _configuration[YokkeApiConstant.Configuration.TokenRequestorId] ?? "";
        string secretKey = _configuration[YokkeApiConstant.Configuration.SecretKey] ?? "";
        string cookie = _configuration["YokkeApi:Cookie"] ?? "";
        string content = _configuration[YokkeApiConstant.Configuration.ContentType] ??
                         YokkeApiConstant.Configuration.ContentTypeJson;

        var payload = JsonSerializer.Serialize(request);
        string signature = HMAC_SHA512(payload, secretKey);

        Dictionary<string, string> headers = new()
        {
            { Authorization, Bearer + jwt },
            { YokkeApiConstant.Header.TokenRequestorId, tokenRequestorId },
            { YokkeApiConstant.Header.Signature, signature }
        };
        if (includeCookie)
            headers.Add("Cookie", cookie);

        var task = BaseApi.Post(_baseUrl + apiUrl, payload, headers, new StringContent(payload, null, content));

        string result = await task;
        var response = JsonSerializer.Deserialize<TResponse>(result) ?? new TResponse();

        if (throwIfFailed && response is IHasResponseCode hasResponse && hasResponse.ResponseCode != "00")
            throw new HttpRequestException(hasResponse.ResponseMessage);

        return response;
    }

    public Task<PostChangeSettlementTypeResponse> UpdateTypeSettlement(PostChangeSettlementTypeRequest request)
    {
        return PostToYokke<PostChangeSettlementTypeRequest, PostChangeSettlementTypeResponse>(
            "YokkeApi:UpdateTypeSettlement", request, includeCookie: true, throwIfFailed: true);
    }

    public Task<PostInquiryDisbursementResponse> InquiryDisbursement(PostInquiryDisbursementRequest request)
    {
        return PostToYokke<PostInquiryDisbursementRequest, PostInquiryDisbursementResponse>(
            "YokkeApi:InquiryDisbursement", request);
    }
    
    public Task<PostInquiryOnDemandResponse> InquiryOnDemand(PostInquiryOnDemandRequest request)
    {
        return PostToYokke<PostInquiryOnDemandRequest, PostInquiryOnDemandResponse>(
            "YokkeApi:InquiryOnDemand", request);
    }

    public async Task<DisbursementOnDemandResponse> DisbursementOnDemand(DisbursementOnDemandRequest request)
    {
        try
        {
            return await PostToYokke<DisbursementOnDemandRequest, DisbursementOnDemandResponse>(
                "YokkeApi:DisbursementOnDemand", request, includeCookie: true, throwIfFailed: true);
        }
        catch (TimeoutException)
        {
            return new DisbursementOnDemandResponse
            {
                AuthorizationDate = request.TransactionDate,
                AuthorizationTime = request.TransactionTime,
                ResponseCode = "68",
                ResponseMessage = "Timeout",
                UserAppId = request.UserAppId,
                StoreCode = request.StoreCode,
                ReffNo = request.ReferenceNo,
                Amount = "0",
                RemainAmount = "0"
            };
        }
    }
}