﻿using System.Net;
using System.Net.Security;
using System.Text;
using LivinMerchant.General.Base.Class.Logger;
using LivinMerchant.General.Base.Helper;
using LivinMerchant.General.Base.Middleware.Models;
using LivinMerchant.Kafka.Services;
using Microsoft.Extensions.Logging;

namespace LM.Settlement.Infrastructure
{
    public class BaseApi
    {
        private static readonly IProducerService ProducerService = new ProducerService();
        private static readonly ILoggerFactory LoggerFactory = new LoggerFactory();

        private static readonly IAppLogger<LoggingEvent> Logger =
            new LoggerAdapter<LoggingEvent>(LoggerFactory, ProducerService);

        private static readonly string BaseApiGet = "BaseApiGet";

        private static readonly bool IsDevelopment =
            string.IsNullOrEmpty(Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT"));

        private static readonly HttpClientHandler ClientHandler;

        static BaseApi()
        {
            ClientHandler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = IsDevelopment
                    ? (_, _, _, _) => true
                    : (sender, cert, chain, errors) => errors == SslPolicyErrors.None
            };
        }


        public static async Task<string> Post(string url, string? param, Dictionary<string, string> headers,
            StringContent? content)
        {
            long startTime = DateTimeOffset.Now.ToUnixTimeMilliseconds();

            var client = new HttpClient(ClientHandler);

            var request = new MaskedHttpRequestMessage
            {
                Method = HttpMethod.Post,
                RequestUri = new Uri(url),
            };

            foreach (var item in headers)
            {
                request.Headers.Add(item.Key, item.Value);
            }

            if (content != null)
            {
                request.Content = content;
                request.Content.Headers.ContentType!.CharSet = "";
            }

            HttpResponseMessage response;

            try
            {
                response = await client.SendAsync(request);
                if (response.StatusCode == HttpStatusCode.OK || response.StatusCode == HttpStatusCode.Created)
                {
                    var res = await response.Content.ReadAsStringAsync();
                    Logger.WriteLog(level: "INFO", startTime: startTime, action: "BaseApiPost", method: "POST",
                        url: url, message: $"BaseAPI request: {param} response: {res}", source: $"BaseApi Post {url}");
                }
                else
                {
                    throw new HttpRequestException(response.ToString());
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(level: "ERROR", startTime: startTime, action: "BaseApiPost", method: "POST", url: url,
                    message: $"BaseAPI request: {param} response error: {ex.StackTrace}", source: $"BaseApi Post {url}",
                    exception: ex);
                throw;
            }

            return await response.Content.ReadAsStringAsync();
        }

        public static async Task<string> Get(string url, Dictionary<string, string>? headers = null,
            Dictionary<string, string>? parameters = null)
        {
            long startTime = DateTimeOffset.Now.ToUnixTimeMilliseconds();

            var client = new HttpClient(ClientHandler);

            string queryParams = "";

            if (parameters != null && parameters.Count != 0)
            {
                var queryBuilder = new StringBuilder("?");

                foreach (var parameter in parameters)
                {
                    queryBuilder.Append(Uri.EscapeDataString(parameter.Key));
                    queryBuilder.Append('=');
                    queryBuilder.Append(Uri.EscapeDataString(parameter.Value));
                    queryBuilder.Append('&');
                }

                queryBuilder.Length--;

                queryParams = queryBuilder.ToString();
            }

            var request = new MaskedHttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri(string.IsNullOrEmpty(queryParams) ? url : $"{url}{queryParams}"),
            };
            if (headers != null)
            {
                foreach (var item in headers)
                {
                    request.Headers.Add(item.Key, item.Value);
                }
            }

            HttpResponseMessage? response = null;
            try
            {
                response = await client.SendAsync(request);
                if (response.StatusCode == HttpStatusCode.OK || response.StatusCode == HttpStatusCode.Created)
                {
                    Logger.WriteLog(level: "INFO", startTime: startTime, action: BaseApiGet, method: "GET", url: url,
                        message: $"BaseAPI request: {request} response: {response.Content.ReadAsStringAsync().Result}",
                        source: $"BaseApi Get {url}");
                }
                else if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    Logger.WriteLog(level: "INFO", startTime: startTime, action: BaseApiGet, method: "GET", url: url,
                        message: $"BaseAPI request: {request} response: {response.Content.ReadAsStringAsync().Result}",
                        source: $"BaseApi Get {url}");
                }
                else
                {
                    Logger.WriteLog(level: "INFO", startTime: startTime, action: BaseApiGet, method: "GET", url: url,
                        message: $"BaseAPI request: {request} response: {response.Content.ReadAsStringAsync().Result}",
                        source: $"BaseApi Get {url}");
                    throw new HttpRequestException(response.ToString());
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(level: "ERROR", startTime: startTime, action: BaseApiGet, method: "GET", url: url,
                    message: $"BaseAPI request: {request} response error: {ex.StackTrace}",
                    source: $"BaseApi Get {url}");
            }

            if (response != null && response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsStringAsync();
            }

            return string.Empty;
        }
    }
}