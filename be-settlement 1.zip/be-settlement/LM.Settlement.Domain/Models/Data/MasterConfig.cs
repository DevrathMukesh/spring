using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.Data
{
    public class MasterConfig : BaseEntity
    {
        [Key]
        [Required]
        public Guid ConfigId { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(255)")]
        public string? ConfigGroup { get; set; }
        
        [Column(TypeName = "nvarchar(255)")]
        public string? ConfigName { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(max)")]
        public string? ConfigValue { get; set; }
        
        [Column(TypeName = "nvarchar(500)")]
        public string? Additional { get; set; }
    }
}