using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.Data.Settlement;

public class BankCode : BaseEntity
{
    [Key]
    [Column("bank_id")]
    public Guid BankId { get; set; }  
    [Column("bank_name")]
    public string BankName { get; set; } = string.Empty; 
    [Column("bank_code")]
    public string Code { get; set; } = string.Empty; 
}
