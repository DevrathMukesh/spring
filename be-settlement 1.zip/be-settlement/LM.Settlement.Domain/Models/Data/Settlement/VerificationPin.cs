using System.ComponentModel.DataAnnotations;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.Data.Settlement;

public class VerificationPin : BaseEntity
{
    [Key]
    [Required]
    public Guid VerificationId { get; set; } 
    public string UserId { get; set; } = string.Empty;
    public string? ServiceCode { get; set; } 
    public string TransactionId { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
}