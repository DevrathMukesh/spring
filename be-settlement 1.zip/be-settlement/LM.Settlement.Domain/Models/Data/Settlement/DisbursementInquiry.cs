using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.Data.Settlement;

public class DisbursementInquiry : BaseDisbursementEntity 
{
    [Key]
    [Required]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    [Column("inquiry_id")]
    public Guid InquiryId { get; set; }
    [Required]
    [Column("user_id")]
    public Guid UserId { get; set; }
    [Required]
    [Column("store_id")]
    public Guid StoreId { get; set; }
    [Required]
    [Column("outlet_id")]
    public Guid OutletId { get; set; }
    [Column("inquiry_datetime")]
    public DateTime? InquiryDatetime { get; set; }
    [Column("available_balance")]
    public decimal AvailableBalance { get; set; }
    [Column("settlement_type")]
    public string? SettlementType { get; set; }
   
}