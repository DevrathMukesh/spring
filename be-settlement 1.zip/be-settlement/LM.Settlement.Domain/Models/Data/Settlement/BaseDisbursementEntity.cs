using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.Data.Settlement;

public abstract class BaseDisbursementEntity : BaseEntity
{
    [Required]
    [Column("gid")]
    public string Gid { get; set; } = string.Empty;
    [Required]
    [Column("disbursement_ref")]
    public string DisbursementRef { get; set; } = string.Empty;
    [Required]
    [Column("store_code")]
    public string StoreCode { get; set; } = string.Empty;
}