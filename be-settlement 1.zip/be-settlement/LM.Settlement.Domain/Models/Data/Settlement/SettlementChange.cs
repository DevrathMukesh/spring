using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.Data.Settlement;

public class SettlementChange : BaseEntity
{
    [Key]
    [Required]
    [Column("settlement_change_id")]
    public Guid SettlementChangeId { get; set; }
    [Required]
    [Column("outlet_id")]
    public Guid OutletId { get; set; }
    [Required]
    [Column("store_id")]
    public Guid StoreId { get; set; }
    [Required]
    [Column("user_id")]
    public Guid UserId { get; set; }
    [Required]
    [Column("old_type")]
    public string OldType { get; set; } = string.Empty;
    [Required]
    [Column("new_type")]
    public string NewType { get; set; } = string.Empty;
    [Required]
    [Column("changes_date")]
    public DateTime ChangesDate { get; set; }
    [Required]
    [Column("changes_effective_date")]
    public DateTime ChangesEffectiveDate { get; set; }
    [Required]
    [Column("is_active")]
    public bool IsActive { get; set; }
    [Required]
    [Column("store_code")]
    public string StoreCode { get; set; } = string.Empty;
    [Column("user_app_id")]
    public string? UserAppId { get; set; }
    [Column("status_code")]
    public string? StatusCode { get; set; }
}