using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LM.Settlement.Domain.Models.Data.Settlement;

public class DisbursementStage : BaseDisbursementEntity
{
    [Key]
    [Required]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    [Column("transaction_id")]
    public Guid TransactionId { get; set; }
    [Required]
    [Column("user_id")]
    public Guid UserId { get; set; }
    [Required]
    [Column("store_id")]
    public Guid StoreId { get; set; }
    [Required]
    [Column("outlet_id")]
    public Guid OutletId { get; set; }
    [Column("inquiry_datetime")]
    public DateTime? InquiryDatetime { get; set; }
    [Required]
    [Column("available_balance")]
    public decimal AvailableBalance { get; set; }
    [Required]
    [Column("withdrawal_amount")]
    public decimal WithdrawalAmount { get; set; }
    [Column("settlement_type")]
    public string? SettlementType { get; set; }
    [Column("expiry_time")]
    public DateTime? ExpiryTime { get; set; }
    [Column("ondemand_type")]
    public string? OndemandType { get; set; }
    [Required]
    [Column("is_used")]
    public bool IsUsed { get; set; }
}
