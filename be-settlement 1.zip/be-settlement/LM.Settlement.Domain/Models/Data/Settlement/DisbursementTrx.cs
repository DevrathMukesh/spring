using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.Data.Settlement;

public class DisbursementTrx : BaseDisbursementEntity
{
    [Key]
    [Required]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    [Column("transaction_id")]
    public Guid TransactionId { get; set; }
    [Required]
    [Column("user_id")]
    public Guid UserId { get; set; }
    [Required]
    [Column("store_id")]
    public Guid StoreId { get; set; }
    [Required]
    [Column("outlet_id")]
    public Guid OutletId { get; set; }
    [Column("inquiry_datetime")]
    public DateTime? InquiryDatetime { get; set; }
    [Required]
    [Column("available_balance")]
    public decimal AvailableBalance { get; set; }
    [Required]
    [Column("withdrawal_amount")]
    public decimal WithdrawalAmount { get; set; }
    [Required]
    [Column("remain_amount")]
    public decimal RemainAmount { get; set; }
    [Column("settlement_type")]
    public string? SettlementType { get; set; }
    [Required]
    [Column("ondemand_type")]
    public string OndemandType { get; set; } = string.Empty;
    [Required]
    [Column("user_app_id")]
    public string UserAppId { get; set; } = string.Empty;
    [Required]
    [Column("reff_no")]
    public string ReffNo { get; set; } = string.Empty;
    [Column("response")]
    public string? Response { get; set; }
    [Column("count_trx")]
    public int? CountTrx { get; set; }
    [Required]
    [Column("is_completed")]
    public bool IsCompleted { get; set; }
}