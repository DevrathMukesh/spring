using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.Data.Settlement;

public class SettlementChangeStage : BaseEntity
{
    [Key]
    [Required]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    [Column("transaction_id")]
    public Guid TransactionId { get; set; }
    [Required]
    [Column("user_id")]
    public Guid UserId { get; set; }
    [Column("store_id")]
    public Guid StoreId { get; set; }
    [Column("outlet_id")]
    public Guid? OutletId { get; set; }
    [Column("old_type")]
    public string? OldType { get; set; }
    [Column("new_type")]
    public string NewType { get; set; } = string.Empty;
    [Column("store_code")]
    public string? StoreCode { get; set; } = string.Empty;
    [Column("changes_date")]
    public DateTime ChangesDate { get; set; }
    [Column("changes_effective_date")]
    public DateTime ChangesEffectiveDate { get; set; }
    [Column("expiry_time")]
    public DateTime ExpiryTime { get; set; }
    [Column("is_used")]
    public bool IsUsed { get; set; }
    [Column("retry")]
    public int Retry { get; set; }
}