using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.Data.Settlement;

public class Config : BaseEntity
{
    [Key]
    [Required]
    [Column("config_id")]
    public Guid ConfigId { get; set; }
    [Column("description")]
    public string? Description { get; set; } = string.Empty;
    [Required]
    [Column("parameter_key")]
    public string ParameterKey { get; set; } = string.Empty;
    [Required]
    [Column("parameter_value")]
    public string ParameterValue { get; set; } = string.Empty;
}