using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.Data;

public class Transactions : BaseEntity
{
    [Key]
    [Required]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public Guid TransactionId { get; set; }

    public Guid OrderId { get; set; }
    public Guid OutletId { get; set; }
    public Guid? RegisterId { get; set; }
    public Guid UserId { get; set; }
    public Guid? PaymentTypeId { get; set; }
    public string Channel { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string? PayoutStatus { get; set; }
    public string? Message { get; set; }
    public string Gateway { get; set; } = string.Empty;
    public string? AuthorizationCode { get; set; }
    public string? ErrorCode { get; set; }
    public string Currency { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string? PaymentInfo { get; set; }
    public bool Test { get; set; }
    public DateTime? SyncTime { get; set; }
    public DateTime? ExternalSyncTime { get; set; }
    [Timestamp] public byte[] Timestamp { get; set; } = [];
    public string? PaymentName { get; set; }
    public string? Reference { get; set; } = string.Empty;
}