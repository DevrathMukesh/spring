using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.Data;

public class Outlets : BaseEntity
{
    [Key]
    [Required]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public Guid OutletId { get; set; }
    public Guid StoreId { get; set; }
    public string? Name { get; set; }
    public string? Phone { get; set; }
    public string? Address { get; set; }
    public string? Address2 { get; set; }
    public string? CountryCode { get; set; }
    public string? Country { get; set; }
    public string? State { get; set; }
    public string? City { get; set; }
    public string? Zip { get; set; }
    public string? ContactName { get; set; }
    public string? Email { get; set; }
    public string? WebSite { get; set; }
    public string? Facebook { get; set; }
    public string? Twitter { get; set; }
    public Guid? ReceiptTemplateId { get; set; }
    public bool? IsPrimary { get; set; }
    public Guid? TaxId { get; set; }
    public DateTime? SyncTime { get; set; }
    public bool IsActive { get; set; }
    public string? Properties { get; set; }
    public string? Type { get; set; }
    public string? OutletCode { get; set; }
    public string? GroupId { get; set; }
    public string? StoreCode { get; set; }
    public int? Level { get; set; }
    public string? SettlementType { get; set; }
    public string? Channels { get; set; }
}