using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.System;

public class StoreMerchantSettings : BaseEntity
{
    [Key]
    [Required]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int StoreMerchantSettingId { get; set; }
    [Required]
    public Guid StoreId { get; set; } = Guid.Empty;
    [Required]
    public int PaymentGatewayId { get; set; }
    [Required]
    public string MerchantId { get; set; } = string.Empty;
    public string? MerchantKey { get; set; }
    public string? Properties { get; set; }
    [Required]
    public DateTime LastUpdated { get; set; } = DateTime.Now;
    public Guid? OutletId { get; set; }
}