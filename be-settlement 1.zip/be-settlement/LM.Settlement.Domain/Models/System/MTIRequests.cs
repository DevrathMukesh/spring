using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LM.Settlement.Domain.Models.System;

public class MtiRequests
{
    [Key]
    [Required]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int MtiRequestId { get; set; }
    
    [Required]
    public Guid StoreId { get; set; }
    [Required]
    public string Status { get; set; } = string.Empty;
    [Required]
    public DateTime CreatedDate { get; set; }
    [Required]
    public string? Type { get; set; } = string.Empty;
    [Required]
    public Guid? OutletId { get; set; }
}