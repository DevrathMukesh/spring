using System.ComponentModel.DataAnnotations;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.System;

public class PaymentGateways : BaseEntity
{
    [Key]
    public int PaymentGatewayId { get; set; }
    public int BankAccountId { get; set; }
    public string? GroupName { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string? Type { get; set; }
    public string? SupportedCountries { get; set; }
    public string Currency { get; set; } = string.Empty;
    public string? MerchantId { get; set; }
    public string? MerchantSettings { get; set; }
    public string? Properties { get; set; }
    public bool IsActive { get; set; }
    public DateTime LastUpdated { get; set; }
}