using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.System;

public class Payouts : BaseEntity
{
    [Key]
    [Required]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int PayoutId { get; set; }

    public Guid StoreId { get; set; }
    public int BankAccountId { get; set; }
    public string Reference { get; set; } = string.Empty;
    public DateTime Date { get; set; }
    public string Currency { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Recipient { get; set; } = string.Empty;
    public string? BankTransferCode { get; set; }
    public string Status { get; set; } = string.Empty;
    public DateTime CompletionDate { get; set; }
    public DateTime LastUpdated { get; set; }
    public string? Properties { get; set; }
    public Guid OutletId { get; set; }
    public string? OnDemandStatus { get; set; }
    public string? SettlementPeriod { get; set; }
    public string? SettlementType { get; set; }
}

public class PayoutsProperties
{
    public DateTime? StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public string? PayoutType { get; set; }
    public string? Period { get; set; }
    public bool? IsFeeInvoiced { get; set; }
    public Guid? OutletId { get; set; }
    public string? OutletName { get; set; }
    public DateTime? ApprovedDate { get; set; }
    public string? ApprovedBy { get; set; }
    public string? CompletedBy { get; set; }
    public string? TransferInfo { get; set; }
    public string? PrincipalName { get; set; }
    public string? PrincipalId { get; set; }
    public string? PrincipalSharingId { get; set; }
    public int? LimitExcludedPayoutAmount { get; set; } 
    public int? LimitExcludedPayoutCount { get; set; }
}

public class PayoutRecipient
{
    public string? OutletPayoutRecipients { get; set; }
    public string? AccountName { get; set; } = string.Empty;
    public string? AccountNumber { get; set; } = string.Empty;
    public string? BankName { get; set; } = string.Empty;
    public string? BankSwiftCode { get; set; } = string.Empty;
    public string? BankCountry { get; set; }
    public string? BankAddress { get; set; }
}

public class PayoutStatusPayoutProperties
{
    public DateTime? StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public string? PayoutType { get; set; }
    public int? Period { get; set; }
    public bool? IsFeeInvoiced { get; set; }
    public Guid? OutletId { get; set; }
    public string? OutletName { get; set; }
    public DateTime? ApprovedDate { get; set; }
    public string? ApprovedBy { get; set; }
    public string? CompletedBy { get; set; }
    public string? TransferInfo { get; set; }
    public string? PrincipalName { get; set; }
    public string? PrincipalSharingId { get; set; }
    public int? LimitExcludedPayoutAmount { get; set; } 
    public int? LimitExcludedPayoutCount { get; set; }
    public List<int>? ManualId { get; set; } 
}