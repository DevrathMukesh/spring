using System.ComponentModel.DataAnnotations;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.System;

public class PayoutPending : BaseEntity
{
    [Key] public Guid PayoutPendingId { get; set; }
    public Guid OutletId { get; set; }
    public string SettlementPeriod { get; set; } = string.Empty;
    public string SettlementType { get; set; } = string.Empty;
    public DateTime SettlementDate { get; set; }
    public string PendingStatus { get; set; } = string.Empty;
    public DateTime TransactionDate { get; set; }
    public decimal PayoutAmount { get; set; }
    public decimal TransactionAmount { get; set; }
    public string PaymentName { get; set; } = string.Empty;
    public string Reference { get; set; } = string.Empty;
    public string InvoiceNo { get; set; } = string.Empty;
    public string? MdrPercentage { get; set; }
    public decimal? MdrFee { get; set; }
    public string? SharingRevPercentage { get; set; }
    public decimal? SharingRevFee { get; set; }
    public decimal? ShippingFee { get; set; }
    public decimal? InsuranceFee { get; set; }
}