using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.System;

public class PaymentGatewayServices : BaseEntity
{
    [Key]
    [Required]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int PaymentGatewayServiceId { get; set; }
    [Required]
    public int PaymentGatewayId { get; set; }
    public int? BankAccountId { get; set; }
    [Required] public string Category { get; set; } = string.Empty;
    [Required]
    public string Name { get; set; } = string.Empty;
    [Required]
    public string Description { get; set; } = string.Empty;
    [Required]
    public double ProcessingRate { get; set; }
    public decimal? AdditionalProcessingAmount { get; set; }
    public double? MarginRate { get; set; }
    public decimal? MarginAmount { get; set; }
    [Required]
    public string InboundPayoutInterval { get; set; } = string.Empty;
    [Required]
    public string OutboundPayoutInterval { get; set; } = string.Empty;
    [Required]
    public string MerchantId { get; set; } = string.Empty;
    [Required]
    public string MerchantKey { get; set; } = string.Empty;
    [Required]
    public bool IsActive { get; set; }
    public bool? IsDefault { get; set; }
    [Required]
    public DateTime LastUpdated { get; set; }
    [Required]
    public string Properties { get; set; } = string.Empty;
    public int? PreferenceLevel { get; set; }
}