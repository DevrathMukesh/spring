using System.ComponentModel.DataAnnotations;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.System;

public class PayoutDetails : BaseEntity
{
    [Key] public int PayoutDetailId { get; set; }
    public int PayoutId { get; set; }
    public int? PaymentGatewayServiceId { get; set; }
    public string? Channel { get; set; } = string.Empty;
    public string? Gateway { get; set; } = string.Empty;
    public string? Type { get; set; } = string.Empty;
    public Guid? Item { get; set; }
    public string? ItemType { get; set; } = string.Empty;
    public string Currency { get; set; } = string.Empty;
    public decimal PayoutAmount { get; set; }
    public decimal TransactionAmount { get; set; }
    public decimal ProcessingAmount { get; set; }
    public decimal MarginAmount { get; set; }
    public string? Properties { get; set; } = string.Empty;
    public decimal? DiscountAmount { get; set; }
    public string? DiscountName { get; set; }
    public string? Identifier { get; set; }
    public string? Reference { get; set; }
}

public class LivinData
{
    public string? PayoutScheduleType { get; set; } = string.Empty;
    public string? PaymentType { get; set; } = string.Empty;
    public DateTime? TransactionDateUtc { get; set; }
    public string? Reference { get; set; } = string.Empty;
    public string? SettlementDate { get; set; } = string.Empty;
    public string? PaymentName { get; set; } = string.Empty;
}

public class PayoutDetailsProperties
{
    public decimal ShippingFee { get; set; }
    public decimal? Deduction { get; set; }
    public decimal SharingProfit { get; set; }
    public string? DetailOriginal { get; set; }
    public decimal? UMKMFee { get; set; }
    public string? PromotionName { get; set; }
    public decimal? AmountChargeMDR { get; set; }
    public LivinData LivinData { get; set; } = new LivinData();
}

public class PayoutStatusLivinData
{
    public string? PayoutScheduleType { get; set; }
    public string? PaymentType { get; set; }
    public string? MerchantID { get; set; }
    public string? MerchantOfficial { get; set; }
    public string? TradingName { get; set; }
    public DateTime? TransactionDateUtc { get; set; }
    public string? PaymentName { get; set; }
    public string? TerminalId { get; set; }
    public string? InvoiceNo { get; set; }
    public string? Reference { get; set; }
    public string? CardType { get; set; }
    public string? SettlementDate { get; set; }
    public string? SaleKindCode { get; set; }
    public string? SaleKindDescription { get; set; }
    public string? PaymentDetail { get; set; }
    public int? Tenor { get; set; }
    public string? CardNumber { get; set; }
    public string? Issuer { get; set; }
    public string? IssuerCountry { get; set; }
    public string? Principal { get; set; }
    public string? PrincipalCode { get; set; }
    public string? OnOffType { get; set; }
    public string? AuthorizationNumber { get; set; }
    public string? AuthorizationBatchNumber { get; set; }
    public string? TerminalBatchNumber { get; set; }
    public string? BatchNumber { get; set; }
    public int? NoMDRTransactionAmount { get; set; }
    public DateTime? TransactionCreatedDateUtc { get; set; }
}

public class PayoutStatusPayoutDetailProperties
{
    public string? MDRFee { get; set; }
    public string? SharingRevFee { get; set; }
    public decimal? SharingFee { get; set; }
    public int? ShippingFee { get; set; }
    public decimal? Deduction { get; set; }
    public decimal SharingProfit { get; set; }
    public string? DetailOriginal { get; set; }
    public decimal? UMKMFee { get; set; }
    public string? PromotionName { get; set; }
    public decimal? AmountChargeMDR { get; set; }
    public PayoutStatusLivinData LivinData { get; set; } = new();
}