using System.ComponentModel.DataAnnotations;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.System;

public class Countries : BaseEntity
{
    [Key] public int CountryId { get; set; }
    public string Name { get; set; } = string.Empty;
}