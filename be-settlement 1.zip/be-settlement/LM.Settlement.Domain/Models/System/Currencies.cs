using System.ComponentModel.DataAnnotations;
using LivinMerchant.General.Base.Class.Model;

namespace LM.Settlement.Domain.Models.System;

public class Currencies : BaseEntity
{
    [Key] public int CurrencyId { get; set; }
    public int? CountryId { get; set; }
    public string? Iso4217 { get; set; }
}