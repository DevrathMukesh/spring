using System.Text.Json.Serialization;

namespace LM.Settlement.Domain.Models.Surrounding.Yokke;

public class PostInquiryDisbursementResponse : BaseYokkeResponse
{
    [JsonPropertyName("userAppID")]
    public string UserAppId { get; set; } = string.Empty;
    [JsonPropertyName("amount")]
    public string Amount { get; set; } = string.Empty;
    [JsonPropertyName("mdr")]
    public string Mdr { get; set; } = string.Empty;
    [JsonPropertyName("amountMdr")]
    public string AmountMdr { get; set; } = string.Empty;
    [JsonPropertyName("sharingFee")]
    public string SharingFee { get; set; } = string.Empty;
    [JsonPropertyName("amountFee")]
    public string AmountFee { get; set; } = string.Empty;
    [JsonPropertyName("settlementType")]
    public string SettlementType { get; set; } = string.Empty;
    [JsonPropertyName("holdAmt")]
    public string HoldAmt { get; set; } = string.Empty;
}