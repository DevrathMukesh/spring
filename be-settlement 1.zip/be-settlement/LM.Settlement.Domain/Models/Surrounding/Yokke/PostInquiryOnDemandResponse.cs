using System.Text.Json.Serialization;

namespace LM.Settlement.Domain.Models.Surrounding.Yokke;

public class PostInquiryOnDemandResponse  : BaseYokkeResponse
{
    [JsonPropertyName("referenceNo")]
    public string ReferenceNo { get; set; } = string.Empty;
    [JsonPropertyName("amount")]
    public string Amount { get; set; } = string.Empty;
    [JsonPropertyName("remainingAmount")]
    public string RemainingAmount { get; set; } = string.Empty;
}