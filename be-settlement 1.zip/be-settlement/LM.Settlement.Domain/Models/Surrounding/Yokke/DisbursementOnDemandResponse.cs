using System.Text.Json.Serialization;

namespace LM.Settlement.Domain.Models.Surrounding.Yokke;

public class DisbursementOnDemandResponse : BaseYokkeResponse
{
    [JsonPropertyName("userAppID")]
    public string UserAppId { get; set; } = string.Empty;
    [JsonPropertyName("referenceNo")]
    public string ReffNo { get; set; } = string.Empty;
    [JsonPropertyName("amount")]
    public string Amount { get; set; } = string.Empty;
    [JsonPropertyName("remainAmount")]
    public string RemainAmount { get; set; } = string.Empty;
}