using System.Text.Json.Serialization;

namespace LM.Settlement.Domain.Models.Surrounding.Yokke;

public class BaseYokkeResponse
{
    [JsonPropertyName("authorizationDate")]
    public string AuthorizationDate { get; set; } = string.Empty;
    [JsonPropertyName("authorizationTime")]
    public string AuthorizationTime { get; set; } = string.Empty;
    [JsonPropertyName("responseCode")]
    public string ResponseCode { get; set; } = string.Empty;
    [JsonPropertyName("responseMessage")]
    public string ResponseMessage { get; set; } = string.Empty;
    [JsonPropertyName("storeCode")]
    public string StoreCode { get; set; } = string.Empty;
}