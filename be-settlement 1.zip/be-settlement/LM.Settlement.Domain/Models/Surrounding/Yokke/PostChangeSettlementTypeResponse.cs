using System.Text.Json.Serialization;

namespace LM.Settlement.Domain.Models.Surrounding.Yokke;

public class PostChangeSettlementTypeResponse : BaseYokkeResponse
{
    [JsonPropertyName("userAppID")]
    public string? UserAppId { get; set; } = string.Empty;
}