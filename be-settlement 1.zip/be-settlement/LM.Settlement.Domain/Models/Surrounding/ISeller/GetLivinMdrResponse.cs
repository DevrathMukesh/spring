namespace LM.Settlement.Domain.Models.Surrounding.ISeller;

public class GetLivinMdrResponse
{
    public List<LivinMdr> MdrList { get; set; } = [];
}

public class LivinMdr
{
    public string PaymentType { get; set; } = string.Empty;
    public string Mdr { get; set; } = string.Empty;
}