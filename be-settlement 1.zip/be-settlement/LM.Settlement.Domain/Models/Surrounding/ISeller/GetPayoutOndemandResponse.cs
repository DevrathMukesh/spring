using System.Text.Json.Serialization;

namespace LM.Settlement.Domain.Models.Surrounding.ISeller;

public class GetPayoutOndemandResponse
{
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public string ResponseCode { get; set; } = string.Empty;
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public List<PayoutDetails> Payouts { get; set; } = [];
}

public class PayoutDetails
{
    public int PayoutId { get; set; }
    public decimal Amount { get; set; }
}