namespace LM.Settlement.Domain.Models.Surrounding.ISeller;

public class BaseResponse<T>
{
    public T Result { get; set; } = default!;
    public string Error { get; set; } = string.Empty;
    public int HttpStatusCode { get; set; }
    public bool Status { get; set; }
}