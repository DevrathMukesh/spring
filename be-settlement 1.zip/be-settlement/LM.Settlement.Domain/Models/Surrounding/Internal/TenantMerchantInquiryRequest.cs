namespace LM.Settlement.Domain.Models.Surrounding.Internal;

public class TenantMerchantInquiryRequest
{
    public Guid OutletId { get; set; }
    public Guid StoreId { get; set; }
}