using Confluent.Kafka;
using LivinMerchant.General.Base.Class.Logger;
using LivinMerchant.Kafka.Models;
using LM.Settlement.Application.Dtos.Event;
using LM.Settlement.Application.Features.Commands.PayoutPendingEvent;
using LM.Settlement.Application.Options;
using MediatR;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using KafkaOptions = LM.Settlement.Application.Options.KafkaOptions;
using LoggingEvent = LivinMerchant.General.Base.Middleware.Models.LoggingEvent;

namespace LM.Settlement.Consumer.Consumer;

public class SettlementPayoutPendingConsumer : BackgroundService
{
    private readonly IServiceScopeFactory _serviceScopeFactory;
    private readonly KafkaOptions _kafkaOptions;
    private readonly IMediator _mediator;
    private const string ConsumerId = "SettlementPayoutPendingConsumer";

    public SettlementPayoutPendingConsumer(IServiceScopeFactory serviceScopeFactory, IOptions<KafkaOptions> options,
        IMediator mediator)
    {
        _serviceScopeFactory = serviceScopeFactory;
        _kafkaOptions = options.Value;
        _mediator = mediator;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        ConsumerConfig config = new ConsumerConfig
        {
            BootstrapServers = _kafkaOptions.BootstrapServers,
            GroupId = _kafkaOptions.ConsumerId,
            AutoOffsetReset = AutoOffsetReset.Earliest,
            EnableAutoCommit = false
        };

        var topicName = _kafkaOptions.TopicNames[TopicNameKeys.SettlementPayoutPending];
        using var consumer = new ConsumerBuilder<Ignore, string>(config).Build();

        try
        {
            consumer.Subscribe(topicName);
            await Task.Run(async () =>
            {
                while (!stoppingToken.IsCancellationRequested)
                {
                    var consumeResult = consumer.Consume(stoppingToken);
                    var message = consumeResult.Message.Value;

                    MessageLogEvent logEvent = new MessageLogEvent
                    {
                        Message = message
                    };

                    long startTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

                    using var scope = _serviceScopeFactory.CreateScope();
                    var logger = scope.ServiceProvider.GetRequiredService<IAppLogger<LoggingEvent>>();

                    logger.WriteLog(level: "INFO", startTime: startTime, action: ConsumerId,
                        method: "Consumer", url: $"Consumer {ConsumerId}",
                        message:
                        $"START_CONSUME_EVENT {topicName} Logevent : {logEvent}",
                        source: $"Consumer {ConsumerId}");
                    try
                    {
                        var parsedContent =
                            JsonConvert.DeserializeObject<ObjectPayoutPendingEvent>(
                                JObject.Parse(message)["Content"]?.ToString() ?? string.Empty);

                        if (parsedContent is null)
                        {
                            consumer.Commit();
                            continue;
                        }

                        var payoutPendingCommand = new PayoutPendingEventCommand
                        {
                            FileName = parsedContent.FileName,
                            OutletId = parsedContent.OutletId,
                            StoreId = parsedContent.StoreId
                        };
                        
                        var result = await _mediator.Send(payoutPendingCommand, stoppingToken);
                        if (!result.IsSuccess)
                        {
                            logger.WriteLog(level: "ERROR", startTime: startTime,
                                action: $"Consumer {ConsumerId}", method: "CONSUMER",
                                url: ConsumerId,
                                message: $"CONSUME_EVENT {topicName} {ConsumerId} {result.Message}",
                                source: $"Consumer {ConsumerId}");
                        }
                        else
                        {
                            logger.WriteLog(level: "INFO", startTime: startTime, action: ConsumerId,
                                method: "Consumer", url: $"Consumer {ConsumerId}",
                                message:
                                $"END_CONSUME_EVENT {topicName} {ConsumerId} IsSuccess {result.IsSuccess}",
                                source: $"Consumer {ConsumerId}");
                        }

                        consumer.Commit();
                    }
                    catch (Exception e)
                    {
                        logEvent.Error = e.ToString();
                        logger.WriteLog(level: "ERROR", startTime: startTime, action: "PayoutPendingConsumer",
                            method: "Consumer", url: "Consumer PayoutPendingConsumer",
                            message: $"CONSUME_EVENT {topicName} : {e.Message}",
                            source: "Consumer PayoutPendingConsumer");
                        consumer.Commit();
                    }
                }

                return Task.CompletedTask;
            }, stoppingToken);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }
}