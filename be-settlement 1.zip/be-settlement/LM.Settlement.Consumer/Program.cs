using LivinMerchant.General.Base.Middleware;
using LivinMerchant.Onboarding.Data;
using LivinMerchant.Onboarding.System;
using LM.Settlement.Application;
using LM.Settlement.Consumer;
using LM.Settlement.Infrastructure;
using LM.Settlement.Persistence;
using KafkaOptions = LM.Settlement.Application.Options.KafkaOptions;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddConsumerServices();
builder.Services.AddHttpContextAccessor();
builder.Services.AddOnboardingSystemContext(builder.Configuration);
builder.Services.AddOnboardingDataContext(builder.Configuration);
builder.Services.AddApplicationServices();
builder.Services.AddInfrastructureServices(builder.Configuration);
builder.Services.AddPersistenceSystemService();
builder.Services.AddPersistenceSettlementService();
builder.Services.AddPersistenceDataService();
builder.Services.AddOptions<KafkaOptions>().Bind(builder.Configuration.GetSection("Kafka"));

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Logging.ClearProviders();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("all");

app.UseMiddleware<RequestMiddleware>();
app.UseMiddleware<ResponseWrapperMiddleware>();

app.UseHttpsRedirection();

app.MapControllers();
await app.RunAsync();