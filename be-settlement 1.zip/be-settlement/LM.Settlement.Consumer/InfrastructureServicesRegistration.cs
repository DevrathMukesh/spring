using LM.Settlement.Consumer.Consumer;

namespace LM.Settlement.Consumer;

public static class InfrastructureServicesRegistration
{
    public static IServiceCollection AddConsumerServices(this IServiceCollection services)
    {
        services.AddHostedService<SettlementPayoutPendingConsumer>();
        return services;
    }
}