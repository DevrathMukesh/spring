using LivinMerchant.General.Base.Class.Context;
using LivinMerchant.General.Base.Class.Model;
using LivinMerchant.General.Base.Helper;
using LM.Settlement.Domain.Models.Data.Settlement;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace LM.Settlement.Persistence.DatabaseContext;

public class SettlementContext : GenericContext<SettlementContext>
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    public DbSet<Config> Configs { get; set; }
    public DbSet<SettlementChange> SettlementChanges { get; set; }
    public DbSet<SettlementChangeStage> SettlementChangeStages { get; set; }
    public DbSet<DisbursementStage> DisbursementStages { get; set; }
    public DbSet<DisbursementInquiry> DisbursementInquiries { get; set; }
    public DbSet<DisbursementTrx> DisbursementTrxs { get; set; }
    public DbSet<BankCode> BankCodes { get; set; }

    public SettlementContext(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(SettlementContext).Assembly);
        modelBuilder.Entity<Config>(entity =>
        {
            entity.ToTable("config");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate).HasColumnName("created_time");
            entity.Property(e => e.ModifiedBy).HasColumnName("updated_by");
            entity.Property(e => e.ModifiedDate).HasColumnName("updated_time");
        });
        modelBuilder.Entity<SettlementChange>(entity =>
        {
            entity.ToTable("settlement_change");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate).HasColumnName("created_time");
            entity.Property(e => e.ModifiedBy).HasColumnName("updated_by");
            entity.Property(e => e.ModifiedDate).HasColumnName("updated_time");
        });
        modelBuilder.Entity<SettlementChangeStage>(entity =>
        {
            entity.ToTable("settlement_change_stage");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate).HasColumnName("created_time");
            entity.Property(e => e.ModifiedBy).HasColumnName("updated_by");
            entity.Property(e => e.ModifiedDate).HasColumnName("updated_time");
        });
        modelBuilder.Entity<DisbursementStage>(entity =>
        {
            entity.ToTable("disbursement_stage");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate).HasColumnName("created_time");
            entity.Property(e => e.ModifiedBy).HasColumnName("updated_by");
            entity.Property(e => e.ModifiedDate).HasColumnName("updated_time");
        });
        modelBuilder.Entity<DisbursementInquiry>(entity =>
        {
            entity.ToTable("disbursement_inquiry");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate).HasColumnName("created_time");
            entity.Property(e => e.ModifiedBy).HasColumnName("updated_by");
            entity.Property(e => e.ModifiedDate).HasColumnName("updated_time");
        });
        modelBuilder.Entity<DisbursementTrx>(entity =>
        {
            entity.ToTable("disbursement_trx");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate).HasColumnName("created_time");
            entity.Property(e => e.ModifiedBy).HasColumnName("updated_by");
            entity.Property(e => e.ModifiedDate).HasColumnName("updated_time");
        });
        modelBuilder.Entity<BankCode>(entity =>
        {
            entity.ToTable("bank_code");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate).HasColumnName("created_time");
            entity.Property(e => e.ModifiedBy).HasColumnName("updated_by");
            entity.Property(e => e.ModifiedDate).HasColumnName("updated_time");
        });
        base.OnModelCreating(modelBuilder);
    }

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        foreach (var entry in base.ChangeTracker.Entries<BaseEntity>()
                     .Where(q => q.State == EntityState.Added || q.State == EntityState.Modified))
        {
            string currentUsername;
            try
            {
                currentUsername = _httpContextAccessor.HttpContext.Items["UserId"] as string ?? "System";
            }
            catch
            {
                currentUsername = "System";
            }

            switch (entry.State)
            {
                case EntityState.Added:

                    entry.Entity.CreatedBy = currentUsername;
                    entry.Entity.CreatedDate = DateTime.Now;
                    entry.Entity.ModifiedBy = entry.Entity.CreatedBy;
                    entry.Entity.ModifiedDate = entry.Entity.CreatedDate;
                    entry.Entity.IsDeleted = false;
                    break;


                case EntityState.Modified:

                    entry.Entity.ModifiedBy = currentUsername;
                    entry.Entity.ModifiedDate = DateTime.Now;
                    break;


                case EntityState.Deleted:

                    entry.State = EntityState.Modified;
                    entry.Entity.ModifiedBy = currentUsername;
                    entry.Entity.ModifiedDate = DateTime.Now;
                    entry.Entity.IsDeleted = true;
                    break;

                default:
                    break;
            }
        }

        Task<int> rowAffected = base.SaveChangesAsync(cancellationToken);

        return rowAffected;
    }

    public override void DatabaseConfig(DbContextOptionsBuilder optionsBuilder)
    {
        var connString = Settings.AppSettingValue("ConnectionStrings", "SettlementConnectionString", "");
        optionsBuilder.UseSqlServer(connString);
    }
}