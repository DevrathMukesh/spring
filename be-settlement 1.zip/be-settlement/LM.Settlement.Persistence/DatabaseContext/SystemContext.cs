using LivinMerchant.General.Base.Class.Context;
using LivinMerchant.General.Base.Class.Model;
using LivinMerchant.General.Base.Helper;
using LM.Settlement.Domain.Models.System;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace LM.Settlement.Persistence.DatabaseContext;

public class SystemContext : GenericContext<SystemContext>
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public DbSet<ConfigParam> ConfigParam { get; set; }
    public DbSet<MtiRequests> MTIRequests { get; set; }
    public DbSet<Payouts> Payouts { get; set; }
    public DbSet<PayoutDetails> PayoutDetails { get; set; }
    public DbSet<StoreMerchantSettings> StoreMerchantSettings { get; set; }
    public DbSet<PaymentGatewayServices> PaymentGatewayServices { get; set; }
    public DbSet<PayoutPending> PayoutPending { get; set; }
    public DbSet<Currencies> Currencies { get; set; }
    public DbSet<Countries> Countries { get; set; }
    public DbSet<PaymentGateways> PaymentGateways { get; set; }

    public SystemContext(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(SystemContext).Assembly);
        modelBuilder.Entity<Payouts>()
            .Ignore(p => p.ModifiedBy)
            .Ignore(p => p.CreatedBy)
            .Ignore(p => p.IsDeleted)
            .Ignore(p => p.ModifiedDate);
        modelBuilder.Entity<PayoutDetails>()
            .Ignore(p => p.ModifiedBy)
            .Ignore(p => p.CreatedBy)
            .Ignore(p => p.IsDeleted)
            .Ignore(p => p.ModifiedDate);
        modelBuilder.Entity<PaymentGatewayServices>()
            .Ignore(p => p.ModifiedBy)
            .Ignore(p => p.CreatedBy)
            .Ignore(p => p.CreatedDate)
            .Ignore(p => p.IsDeleted)
            .Ignore(p => p.ModifiedDate);
        modelBuilder.Entity<StoreMerchantSettings>()
            .Ignore(p => p.ModifiedBy)
            .Ignore(p => p.CreatedBy)
            .Ignore(p => p.CreatedDate)
            .Ignore(p => p.IsDeleted)
            .Ignore(p => p.ModifiedDate);
        modelBuilder.Entity<Countries>()
            .Ignore(p => p.CreatedBy)
            .Ignore(p => p.CreatedDate)
            .Ignore(p => p.ModifiedBy)
            .Ignore(p => p.ModifiedDate);
        modelBuilder.Entity<Currencies>()
            .Ignore(p => p.CreatedBy)
            .Ignore(p => p.CreatedDate)
            .Ignore(p => p.ModifiedBy)
            .Ignore(p => p.ModifiedDate);
        modelBuilder.Entity<PaymentGateways>()
            .Ignore(p => p.CreatedBy)
            .Ignore(p => p.CreatedDate)
            .Ignore(p => p.ModifiedBy)
            .Ignore(p => p.ModifiedDate);

        base.OnModelCreating(modelBuilder);
    }

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        foreach (var entry in base.ChangeTracker.Entries<BaseEntity>()
                     .Where(q => q.State == EntityState.Added || q.State == EntityState.Modified))
        {
            var userId = _httpContextAccessor.HttpContext?.Items["UserId"] as string;

            string currentUsername = userId ?? "SYSTEM";
            switch (entry.State)
            {
                case EntityState.Added:

                    entry.Entity.CreatedBy = currentUsername;
                    entry.Entity.CreatedDate = DateTime.UtcNow;
                    entry.Entity.ModifiedBy = entry.Entity.CreatedBy;
                    entry.Entity.ModifiedDate = entry.Entity.CreatedDate;
                    entry.Entity.IsDeleted = false;
                    break;

                case EntityState.Modified:

                    entry.Entity.ModifiedBy = currentUsername;
                    entry.Entity.ModifiedDate = DateTime.UtcNow;
                    break;


                case EntityState.Deleted:

                    entry.State = EntityState.Modified;
                    entry.Entity.ModifiedBy = currentUsername;
                    entry.Entity.ModifiedDate = DateTime.UtcNow;
                    entry.Entity.IsDeleted = true;
                    break;

                default:
                    break;
            }
        }

        Task<int> rowAffected = base.SaveChangesAsync(cancellationToken);

        return rowAffected;
    }

    public override void DatabaseConfig(DbContextOptionsBuilder optionsBuilder)
    {
        var connString = Settings.AppSettingValue("ConnectionStrings", "OnboardingConnectionString", "");
        optionsBuilder.UseSqlServer(connString);
    }
}