using LivinMerchant.General.Base.Class.Context;
using LivinMerchant.General.Base.Class.Model;
using LivinMerchant.General.Base.Helper;
using LM.Settlement.Domain.Models.Data;
using LM.Settlement.Domain.Models.Data.Settlement;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace LM.Settlement.Persistence.DatabaseContext;

public class DataContext : GenericContext<DataContext>
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public DbSet<Transactions> Transactions { get; set; }
    public DbSet<Outlets> Outlets { get; set; }
    public DbSet<MasterConfig> MasterConfig { get; set; }
    public DbSet<VerificationPin> VerificationPin { get; set; }

    public DataContext(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(DataContext).Assembly);
        base.OnModelCreating(modelBuilder);
    }

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        foreach (var entry in base.ChangeTracker.Entries<BaseEntity>()
                     .Where(q => q.State == EntityState.Added || q.State == EntityState.Modified))
        {
            string currentUsername;
            try
            {
                currentUsername = (_httpContextAccessor.HttpContext.Items["UserId"] as string) ?? "System";
            }
            catch
            {
                currentUsername = "System";
            }

            var now = DateTime.UtcNow;

            switch (entry.State)
            {
                case EntityState.Added:
                    entry.Entity.CreatedBy = currentUsername;
                    entry.Entity.CreatedDate = now;
                    entry.Entity.IsDeleted = false;
                    goto case EntityState.Modified;

                case EntityState.Deleted:
                    entry.State = EntityState.Modified;
                    entry.Entity.IsDeleted = true;
                    goto case EntityState.Modified;

                case EntityState.Modified:
                    entry.Entity.ModifiedBy = currentUsername;
                    entry.Entity.ModifiedDate = now;
                    break;
            }
        }

        Task<int> rowAffected = base.SaveChangesAsync(cancellationToken);

        return rowAffected;
    }

    public override void DatabaseConfig(DbContextOptionsBuilder optionsBuilder)
    {
        var connString = Settings.AppSettingValue("ConnectionStrings", "OnboardingDataConnectionString", "");
        optionsBuilder.UseSqlServer(connString);
        optionsBuilder.EnableSensitiveDataLogging();
    }
}