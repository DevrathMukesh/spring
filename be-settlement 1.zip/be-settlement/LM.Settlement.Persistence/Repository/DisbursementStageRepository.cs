using LivinMerchant.General.Base.Class.Repository;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.Data.Settlement;
using LM.Settlement.Persistence.DatabaseContext;

namespace LM.Settlement.Persistence.Repository;

public class DisbursementStageRepository : GenericRepository<DisbursementStage, SettlementContext>,
    IDisbursementStageRepository
{
    public DisbursementStageRepository(SettlementContext dbContext) : base(dbContext)
    {
    }
}