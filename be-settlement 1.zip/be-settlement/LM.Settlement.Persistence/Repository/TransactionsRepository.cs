using LivinMerchant.General.Base.Class.Repository;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.Data;
using LM.Settlement.Persistence.DatabaseContext;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace LM.Settlement.Persistence.Repository;

public class TransactionsRepository : GenericRepository<Transactions, DataContext>, ITransactionsRepository
{
    public TransactionsRepository(DataContext dbContext) : base(dbContext)
    {
    }
}