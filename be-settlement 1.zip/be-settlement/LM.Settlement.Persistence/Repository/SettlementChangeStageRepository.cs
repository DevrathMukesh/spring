using LivinMerchant.General.Base.Class.Repository;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.Data;
using LM.Settlement.Domain.Models.Data.Settlement;
using LM.Settlement.Persistence.DatabaseContext;

namespace LM.Settlement.Persistence.Repository;

public class SettlementChangeStageRepository : GenericRepository<SettlementChangeStage, SettlementContext>,
    ISettlementChangeStageRepository
{
    public SettlementChangeStageRepository(SettlementContext dbContext) : base(dbContext)
    {
    }
}