using LivinMerchant.General.Base.Class.Repository;
using LivinMerchant.Redis.Services;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.Data.Settlement;
using LM.Settlement.Persistence.DatabaseContext;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace LM.Settlement.Persistence.Repository;

public class BankCodeRepository : GenericRepository<BankCode, SettlementContext>, IBankCodeRepository
{
    private readonly IConfiguration _configuration;
    private readonly IRedisService _redisService;
    private readonly SettlementContext _dbContext;

    public BankCodeRepository(SettlementContext dbContext, IConfiguration configuration, IRedisService redisService) :
        base(dbContext)
    {
        _dbContext = dbContext;
        _configuration = configuration;
        _redisService = redisService;
    }

    public async Task<List<BankCode>> GetFromRedis()
    {
        var bankCodeKey = _configuration["Redis:CacheKeys:BankCode:Key"] ?? "BankCode";
        var bankCodeTimespan = Convert.ToInt32(_configuration["Redis:CacheKeys:BankCode:TimeSpan"]);

        List<BankCode> redisConfig =
            await _redisService.GetAsync<List<BankCode>>(bankCodeKey);
        if (redisConfig == null)
        {
            redisConfig = await _dbContext.BankCodes.AsNoTracking().Where(x => !x.IsDeleted).ToListAsync();
            await _redisService.SetAsync(bankCodeKey, redisConfig,
                TimeSpan.FromMinutes(bankCodeTimespan));
        }

        return redisConfig;
    }
}