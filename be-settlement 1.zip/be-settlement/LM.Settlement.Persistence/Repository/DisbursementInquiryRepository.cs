using LivinMerchant.General.Base.Class.Repository;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.Data.Settlement;
using LM.Settlement.Persistence.DatabaseContext;

namespace LM.Settlement.Persistence.Repository;

public class DisbursementInquiryRepository : GenericRepository<DisbursementInquiry, SettlementContext>,
    IDisbursementInquiryRepository
{
    public DisbursementInquiryRepository(SettlementContext dbContext) : base(dbContext)
    {
    }
}