using LivinMerchant.General.Base.Class.Repository;
using LivinMerchant.Redis.Services;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.System;
using LM.Settlement.Persistence.DatabaseContext;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace LM.Settlement.Persistence.Repository;

public class CountriesRepository : GenericRepository<Countries, SystemContext>, ICountriesRepository
{
    private readonly IRedisService _redisService;
    private readonly IConfiguration _configuration;
    private readonly SystemContext _dbContext;

    public CountriesRepository(SystemContext dbContext, IRedisService redisService, IConfiguration configuration) :
        base(dbContext)
    {
        _dbContext = dbContext;
        _redisService = redisService;
        _configuration = configuration;
    }

    public async Task<List<Countries>> GetFromRedis()
    {
        var configKey = _configuration["Redis:CacheKeys:Countries:Key"] ?? "Countries";
        var configTimespan = Convert.ToInt32(_configuration["Redis:CacheKeys:Countries:TimeSpan"]);

        List<Countries> redisConfig =
            await _redisService.GetAsync<List<Countries>>(configKey);
        if (redisConfig == null)
        {
            redisConfig = await _dbContext.Countries.AsNoTracking().Where(x => !x.IsDeleted).ToListAsync();
            await _redisService.SetAsync(configKey, redisConfig,
                TimeSpan.FromMinutes(configTimespan));
        }

        return redisConfig;
    }
}