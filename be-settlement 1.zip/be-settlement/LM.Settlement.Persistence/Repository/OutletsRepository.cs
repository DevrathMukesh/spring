using LivinMerchant.General.Base.Class.Repository;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.Data;
using LM.Settlement.Persistence.DatabaseContext;

namespace LM.Settlement.Persistence.Repository;

public class OutletsRepository : GenericRepository<Outlets, DataContext>, IOutletsRepository
{
    public OutletsRepository(DataContext dbContext) : base(dbContext)
    {
    }
}