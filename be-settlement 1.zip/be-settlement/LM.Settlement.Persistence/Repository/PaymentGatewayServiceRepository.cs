using LivinMerchant.General.Base.Class.Repository;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.System;
using LM.Settlement.Persistence.DatabaseContext;

namespace LM.Settlement.Persistence.Repository;

public class PaymentGatewayServiceRepository : GenericRepository<PaymentGatewayServices, SystemContext>, IPaymentGatewayServicesRepository
{
    private readonly SystemContext _context;
    
    public PaymentGatewayServiceRepository(SystemContext dbContext, SystemContext systemContext) : base(dbContext)
    {
        _context = systemContext;
    }
    public IQueryable<PaymentGatewayServices> GetQueryable()
    {
        return _context.PaymentGatewayServices;
    }
}