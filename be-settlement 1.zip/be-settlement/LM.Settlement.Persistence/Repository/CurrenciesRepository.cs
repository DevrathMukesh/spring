using LivinMerchant.General.Base.Class.Repository;
using LivinMerchant.Redis.Services;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.System;
using LM.Settlement.Persistence.DatabaseContext;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace LM.Settlement.Persistence.Repository;

public class CurrenciesRepository : GenericRepository<Currencies, SystemContext>,
    ICurrenciesRepository
{
    private readonly IRedisService _redisService;
    private readonly IConfiguration _configuration;
    private readonly SystemContext _dbContext;

    public CurrenciesRepository(SystemContext dbContext, IRedisService redisService, IConfiguration configuration) :
        base(dbContext)
    {
        _dbContext = dbContext;
        _redisService = redisService;
        _configuration = configuration;
    }

    public async Task<List<Currencies>> GetFromRedis()
    {
        var configKey = _configuration["Redis:CacheKeys:Currencies:Key"] ?? "Currencies";
        var configTimespan = Convert.ToInt32(_configuration["Redis:CacheKeys:Currencies:TimeSpan"]);

        List<Currencies> redisConfig =
            await _redisService.GetAsync<List<Currencies>>(configKey);
        if (redisConfig == null)
        {
            redisConfig = await _dbContext.Currencies.AsNoTracking().Where(x => !x.IsDeleted).ToListAsync();
            await _redisService.SetAsync(configKey, redisConfig,
                TimeSpan.FromMinutes(configTimespan));
        }

        return redisConfig;
    }
}