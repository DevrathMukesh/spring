using LivinMerchant.General.Base.Class.Repository;
using LivinMerchant.Redis.Services;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.Data;
using LM.Settlement.Persistence.DatabaseContext;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace LM.Settlement.Persistence.Repository
{
	public class MasterConfigRepository : GenericRepository<MasterConfig, DataContext>, IMasterConfigRepository
	{
        private readonly IRedisService _redisService;
        protected readonly DataContext Context;
        private readonly IConfiguration _configuration;

        public MasterConfigRepository(DataContext context, IRedisService redisService, IConfiguration configuration) : base(context)
		{
            Context = context;
            _redisService = redisService;
            _configuration = configuration;
        }

        public async Task<List<MasterConfig>> GetFromRedis()
        {
            var masterConfigKey = _configuration["Redis:CacheKeys:MasterConfig:Key"] ?? "LivinDataMasterConfig";
            var masterConfigTimespan = Convert.ToInt32(_configuration["Redis:CacheKeys:MasterConfig:TimeSpan"]);
            List<MasterConfig> configs;
            List<MasterConfig> redisConfig = await _redisService.GetAsync<List<MasterConfig>>(masterConfigKey);
            if (redisConfig != null)
                configs = redisConfig;
            else
            {
                configs = await Context.MasterConfig.AsNoTracking().Where(x => !x.IsDeleted).ToListAsync();
                await _redisService.SetAsync(masterConfigKey, configs, TimeSpan.FromMinutes(masterConfigTimespan));
            }
            return configs;
        }

    }
}

