using LivinMerchant.General.Base.Class.Context;
using LivinMerchant.General.Base.Class.Repository;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.System;
using LM.Settlement.Persistence.DatabaseContext;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace LM.Settlement.Persistence.Repository;

public class PayoutsRepository : GenericRepository<Payouts, SystemContext>, IPayoutsRepository
{
    private readonly SystemContext _context;

    public PayoutsRepository(SystemContext dbContext, SystemContext context) : base(dbContext)
    {
        _context = context;
    }

    public async Task<int> UpdatePayouts(Payouts instance)
    {
        int affectedRows = await _context.Database.ExecuteSqlRawAsync(
            "UPDATE Payouts SET Amount = @amount WHERE PayoutId = @payoutId",
            new SqlParameter("@amount", instance.Amount),
            new SqlParameter("@payoutId", instance.PayoutId)
        );
        return affectedRows;
    }
}