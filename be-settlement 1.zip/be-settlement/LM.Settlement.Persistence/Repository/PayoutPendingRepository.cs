using LivinMerchant.General.Base.Class.Repository;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.System;
using LM.Settlement.Persistence.DatabaseContext;

namespace LM.Settlement.Persistence.Repository;

public class PayoutPendingRepository : GenericRepository<PayoutPending, SystemContext>, IPayoutPendingRepository
{
    public PayoutPendingRepository(SystemContext dbContext) : base(dbContext)
    {
    }
}