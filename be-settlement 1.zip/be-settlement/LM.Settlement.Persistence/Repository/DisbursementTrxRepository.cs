using LivinMerchant.General.Base.Class.Repository;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.Data.Settlement;
using LM.Settlement.Persistence.DatabaseContext;

namespace LM.Settlement.Persistence.Repository;

public class DisbursementTrxRepository : GenericRepository<DisbursementTrx, SettlementContext>,
    IDisbursementTrxRepository
{
    public DisbursementTrxRepository(SettlementContext dbContext) : base(dbContext)
    {
    }
}