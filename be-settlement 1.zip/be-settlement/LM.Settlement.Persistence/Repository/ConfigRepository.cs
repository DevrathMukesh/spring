using LivinMerchant.General.Base.Class.Repository;
using LivinMerchant.Redis.Services;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Domain.Models.Data.Settlement;
using LM.Settlement.Persistence.DatabaseContext;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace LM.Settlement.Persistence.Repository;

public class ConfigRepository : GenericRepository<Config, SettlementContext>, IConfigRepository
{
    private readonly IRedisService _redisService;
    private readonly SettlementContext _dbContext;
    private readonly IConfiguration _configuration;

    public ConfigRepository(SettlementContext dbContext, IRedisService redisService, IConfiguration configuration) :
        base(dbContext)
    {
        _dbContext = dbContext;
        _redisService = redisService;
        _configuration = configuration;
    }

    public async Task<List<Config>> GetFromRedis()
    {
        var configKey = _configuration["Redis:CacheKeys:Config:Key"] ?? "Config";
        var configTimespan = Convert.ToInt32(_configuration["Redis:CacheKeys:Config:TimeSpan"]);

        List<Config> redisConfig =
            await _redisService.GetAsync<List<Config>>(configKey);
        if (redisConfig == null)
        {
            redisConfig = await _dbContext.Configs.AsNoTracking().Where(x => !x.IsDeleted).ToListAsync();
            await _redisService.SetAsync(configKey, redisConfig,
                TimeSpan.FromMinutes(configTimespan));
        }

        return redisConfig;
    }
}