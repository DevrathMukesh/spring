using LivinMerchant.Helpers;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Persistence.DatabaseContext;
using LM.Settlement.Persistence.Repository;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace LM.Settlement.Persistence;

public static class PersistenceDataServiceRegistration
{
    public static IServiceCollection AddPersistenceDataService(this IServiceCollection services)
    {
        var dbConnection = Settings.AppSettingValue("ConnectionStrings", "OnboardingDataConnectionString");

        services.AddDbContext<DataContext>(option => { option.UseSqlServer(dbConnection); });

        services.AddScoped<ITransactionsRepository, TransactionsRepository>();
        services.AddScoped<IOutletsRepository, OutletsRepository>();
        services.AddScoped<IMasterConfigRepository, MasterConfigRepository>();
        services.AddScoped<IVerificationPinRepository, VerificationPinRepository>();

        return services;
    }
}