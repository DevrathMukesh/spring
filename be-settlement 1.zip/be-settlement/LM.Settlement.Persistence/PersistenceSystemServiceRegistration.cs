﻿using LivinMerchant.General.Base.Helper;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Persistence.DatabaseContext;
using LM.Settlement.Persistence.Repository;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace LM.Settlement.Persistence;

public static class PersistenceSystemServiceRegistration
{
    public static IServiceCollection AddPersistenceSystemService(this IServiceCollection services)
    {
        var connString = Settings.AppSettingValue("ConnectionStrings", "OnboardingConnectionString");

        services.AddDbContext<SystemContext>(option => { option.UseSqlServer(connString); });

        services.AddScoped<IConfigParamRepository, ConfigParamRepository>();
        services.AddScoped<IMtiRequestsRepository, MtiRequestsRepository>();
        services.AddScoped<IPayoutsRepository, PayoutsRepository>();
        services.AddScoped<IPayoutDetailsRepository, PayoutDetailsRepository>();
        services.AddScoped<IStoreMerchantSettingsRepository, StoreMerchantSettingsRepository>();
        services.AddScoped<IPaymentGatewayServicesRepository, PaymentGatewayServiceRepository>();
        services.AddScoped<IPayoutPendingRepository, PayoutPendingRepository>();
        services.AddScoped<ICurrenciesRepository, CurrenciesRepository>();
        services.AddScoped<ICountriesRepository, CountriesRepository>();
        services.AddScoped<IPaymentGatewaysRepository, PaymentGatewaysRepository>();

        return services;
    }
}