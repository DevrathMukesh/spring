using LivinMerchant.Helpers;
using LM.Settlement.Application.Contracts;
using LM.Settlement.Application.Contracts.Infrastructure;
using LM.Settlement.Persistence.DatabaseContext;
using LM.Settlement.Persistence.Repository;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace LM.Settlement.Persistence;

public static class PersistenceSettlementServiceRegistration
{
    public static IServiceCollection AddPersistenceSettlementService(this IServiceCollection services)
    {
        var dbConnection = Settings.AppSettingValue("ConnectionStrings", "SettlementConnectionString");

        services.AddDbContext<SettlementContext>(option => { option.UseSqlServer(dbConnection); });

        services.AddScoped<IConfigRepository, ConfigRepository>();
        services.AddScoped<ISettlementChangeRepository, SettlementChangeRepository>();
        services.AddScoped<ISettlementChangeStageRepository, SettlementChangeStageRepository>();
        services.AddScoped<IDisbursementStageRepository, DisbursementStageRepository>();
        services.AddScoped<IDisbursementInquiryRepository, DisbursementInquiryRepository>();
        services.AddScoped<IDisbursementTrxRepository, DisbursementTrxRepository>();
        services.AddScoped<IBankCodeRepository, BankCodeRepository>();
        return services;
    }
}